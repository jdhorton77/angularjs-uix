/// <reference path="../common/angular.js" />
/// <reference path="../common/jquery-1.10.2.js" />
/// <reference path="../common/jquery-ui.min.js" />
/// <reference path="../Utilities.js" />


(function (window, $) {
    'use strict';

    window.uixControls = {};
    var controls = angular.module('uixControls.directives', []);
    angular.module('uixControls', ['uixControls.directives']);

    if (!$) {
        throw new Error('JQuery is required.');
    }

    var _uix = {
        findNgRepeatElement: function (collectionName, context) {
            return context ? $(''.concat('*[ng-repeat~="', collectionName, '"]'), context) : $(''.concat('*[ng-repeat~="', collectionName, '"]'));
        },
        getNgRepeatProps: function (element) {
            if (!element.attr('ng-repeat')) return;
            var repeaterExpression = element.attr('ng-repeat'),
                pattern = /^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?\s*$/i,
                match = repeaterExpression.match(pattern),
                isKVP = /\([\w,\s\w]+\)/.test(match[1]),
                kvpSplit = match[1].replace(/\(\)\s/g, '').split(',');

            return match ? { objName: match[1], collectionName: match[2], trackBy: match[3], isKeyValuePair: /\([\w,\s\w]+\)/.test(match[1]), keyName: kvpSplit[0], valueName: kvpSplit[1] } : null;
        },
        appendNgClass: function (element, propName, className, repeaterObjName) {
            var uixClassValue = '',
                ngClassValue = element.attr('ng-class') != undefined ? element.attr('ng-class') : '',
                isNgClassObject = /\{/.test(ngClassValue),
                isNgClassArray = /\[/.test(ngClassValue),
                index = -1;

            if (isNgClassArray) {
                index = ngClassValue.search(/\s?\]/);
                uixClassValue = repeaterObjName
                    ? ', '.concat(repeaterObjName, '.', propName, ' ? "', className, '" : ""')
                    : ', '.concat(propName, ' ? "', className, '" : ""');
                ngClassValue = ''.concat(ngClassValue.substr(0, index), uixClassValue, ngClassValue.substr(index));
            }
            else if (isNgClassObject) {
                index = ngClassValue.search(/\s?\}/);
                uixClassValue = repeaterObjName
                    ? ', '.concat(className, ': ', repeaterObjName, '.', propName)
                    : ', '.concat(className, ': ', propName);
                ngClassValue = ''.concat(ngClassValue.substr(0, index), uixClassValue, ngClassValue.substr(index));
            }
            else {
                index = ngClassValue.length;
                if (index == 0) {
                    uixClassValue = repeaterObjName
                        ? ''.concat(repeaterObjName, '.', propName, ' ? "', className, '" : ""')
                        : ''.concat(propName, ' ? "', className, '" : ""');
                }
                else {
                    uixClassValue = repeaterObjName
                        ? ', '.concat(repeaterObjName, '.', propName, ' ? "', className, '" : ""')
                        : ', '.concat(propName, ' ? "', className, '" : ""');
                }

                ngClassValue = '[ '.concat(ngClassValue.substr(0, index), uixClassValue, ngClassValue.substr(index), ' ]');
            }

            element.attr({ 'ng-class': ngClassValue });
        }
    };

    controls.directive('uixPagination', ['$parse', '$timeout', function ($parse, $timeout) {
        return {
            restrict: 'A',
            replace: false,
            scope: {
                //pageSizes: '&',
                selectedPagesize: '=',
                virtualCount: '=',
                currentPage: '='
                //needsReset: '&'
            },
            template: '<div ng-show="showButtons && !isVirtualScroll" style="float: left; margin: auto; margin-top: 0px; margin-left: 25px;">' +
                              '<ul class="pagination pagination-sm" style="margin: 0px;">' +
                                  '<li><span ng-click="gotoPreviousPage()"><<</span></li>' +
                                  '<li><span ng-repeat="number in pages"' +
                                      'ng-class="{ currentButton : currentPage == number }"' +
                                      'ng-click="setCurrentPage(number)">{{ number }}</span></li>' +
                                  '<li><span ng-click="gotoNextPage()">>></span></li>' +
                              '</ul>' +
                      '</div>' +
                      '<div ng-show="showPagesizes" style="float: left; margin: auto; margin-left: 35px;">' +
                          '<select ng-model="selectedPagesize" ng-options="size for size in pageSizes" style="width: 75px;"></select>' +
                      '</div>' +
                      '<div ng-show="showTotalcount" style="float: right; margin: auto; margin-top: 3px; margin-right: 25px;">{{ virtualCount }} total items.</div>' +
                      '<div ng-show="showPagecount" style="float: right; margin: auto; margin-top: 3px; margin-right: 25px;">{{ currentPage }} of {{ pageCount() }} pages.</div>',
            link: function (localScope, element, attrs, controller) {
                var scope = localScope.$parent,
                    pageSizeMissing = true,
                    pageSizeLength = 0,
                    i = 0,
                    onPageIndexChange = attrs.onPageIndexChange && attrs.onPageIndexChange !== "" ? attrs.onPageIndexChange : null,
                    onPageSizeChange = attrs.onPageSizeChange && attrs.onPageSizeChange !== "" ? attrs.onPageSizeChange : null,
                    onPageReset = attrs.onPageReset && attrs.onPageReset !== "" ? attrs.onPageReset : null;

                if (localScope.virtualCount == undefined) {
                    throw new Error('Missing required directive "virtual-count" of uixPagination. This property is needed for calculating the number of pages.');
                }

                if (localScope.selectedPagesize == undefined) {
                    localScope.selectedPagesize = 100;
                    console.warn('Directive "selected-pagesize" of uixPagination is undefined. Without this property, parent scope can not be notified of current selected page size. Initial value should be "100" unless other page sizes are defined.');
                }

                if (localScope.currentPage == undefined) {
                    localScope.currentPage = 1;
                    console.warn('Directive "current-page" of uixPagination is undefined. Without this property, parent scope can be notified of current page value. Initial value should be "1".');
                }

                localScope.pageSizes = [100, 250, 500, 750, 1000];


                if (localScope.selectedPagesize !== null && localScope.selectedPagesize > 0) {
                    pageSizeLength = localScope.pageSizes.length;

                    while (i < pageSizeLength && pageSizeMissing) {
                        if (localScope.selectedPagesize == localScope.pageSizes[i]) {
                            pageSizeMissing = false;
                        }
                        i++;
                    }
                }
                if (pageSizeMissing) {
                    localScope.selectedPagesize = 100;
                }

                localScope.rangeSize = 5;
                localScope.pageRange = {
                    start: 1,
                    end: 5
                };
                localScope.pageCount = function () {
                    return Math.ceil(localScope.virtualCount / localScope.selectedPagesize);
                };
                localScope.setCurrentPage = function (pageNumber) {
                    localScope.currentPage = pageNumber;
                };
                localScope.gotoPreviousPage = function () {
                    if (localScope.currentPage > 1) {
                        localScope.currentPage = localScope.currentPage - 1;
                    }
                };
                localScope.gotoNextPage = function () {
                    if (localScope.currentPage < localScope.pageCount()) {
                        localScope.currentPage = localScope.currentPage + 1;
                    }
                };
                localScope.hasNextPage = function () {
                    return (localScope.currentPage) <= localScope.pageCount();
                };
                localScope.hasPreviousPage = function () {
                    return (localScope.currentPage) > 0;
                };
                localScope.reset = function () {
                    localScope.isResetting = true;
                    localScope.pages = [];
                    localScope.currentPage = 1;
                    localScope.pageRange.start = 1;
                    localScope.pageRange.end = Math.min(localScope.rangeSize, localScope.pageCount());
                    for (var i = localScope.pageRange.start; i <= localScope.pageRange.end; i++) {
                        localScope.pages.push(i);
                    }

                };
                localScope.pages = [];

                localScope.isMouseDown = false;
                localScope.isChanging = false;
                localScope.direction = '';
                localScope.isVirtualScroll = false;
                localScope.showButtons = true;
                localScope.showPagesizes = true;
                localScope.showPagecount = true;
                localScope.showTotalcount = true;

                if (attrs.virtualScroll && attrs.virtualScroll !== "") {
                    scope.$watch(function () {
                        return scope[attrs.virtualScroll] !== undefined ? scope[attrs.virtualScroll] : scope.$eval(attrs.virtualScroll);
                    }, function (newValue) {
                        localScope.isVirtualScroll = newValue;
                        if (localScope.isVirtualScroll) {
                            bindVirtualScrolling();
                        }
                        else {
                            unbindVirtualScrolling();
                        }
                    }, true);
                }

                if (attrs.showButtons && attrs.showButtons !== "") {
                    scope.$watch(function () {
                        return scope[attrs.showButtons] !== undefined ? scope[attrs.showButtons] : scope.$eval(attrs.showButtons);
                    }, function (newValue) {
                        localScope.showButtons = newValue;
                    }, true);
                }

                if (attrs.showPagesizes && attrs.showPagesizes !== "") {
                    scope.$watch(function () {
                        return scope[attrs.showPagesizes] !== undefined ? scope[attrs.showPagesizes] : scope.$eval(attrs.showPagesizes);
                    }, function (newValue) {
                        localScope.showPagesizes = newValue;
                    }, true);
                }

                if (attrs.showPagecount && attrs.showPagecount !== "") {
                    scope.$watch(function () {
                        return scope[attrs.showPagecount] !== undefined ? scope[attrs.showPagecount] : scope.$eval(attrs.showPagecount);
                    }, function (newValue) {
                        localScope.showPagecount = newValue;
                    }, true);
                }

                if (attrs.showTotalcount && attrs.showTotalcount !== "") {
                    scope.$watch(function () {
                        return scope[attrs.showTotalcount] !== undefined ? scope[attrs.showTotalcount] : scope.$eval(attrs.showTotalcount);
                    }, function (newValue) {
                        localScope.showTotalcount = newValue;
                    }, true);
                }

                localScope.needsReset = false;
                if (attrs.needsReset && attrs.needsReset !== "") {
                    scope.$watch(function () {
                        return scope[attrs.needsReset];
                    }, function (newValue, oldValue) {
                        if (newValue === true) {
                            localScope.reset();
                            scope[attrs.needsReset] = false;
                            localScope.$emit('onPageReset');
                            if (onPageReset) {
                                $parse(onPageReset)(scope, { $event: { target: $(element), pageSize: localScope.selectedPagesize, currentPage: 1 } });
                            }
                        }
                    }, true);
                }

                if (attrs.pageSizes && attrs.pageSizes !== "") {
                    scope.$watch(function () {
                        return scope[attrs.pageSizes] !== undefined ? scope[attrs.pageSizes] : scope.$eval(attrs.pageSizes);
                    }, function (newValue) {
                        var l = localScope.pageSizes.length,
                            x = 0,
                            missing = true;

                        localScope.pageSizes = scope[attrs.pageSizes];

                        while (x < l && missing) {
                            if (localScope.selectedPagesize == localScope.pageSizes[x]) {
                                missing = false;
                            }
                            else {
                                x++;
                            }
                        }

                        if (missing) {
                            localScope.selectedPagesize = localScope.pageSizes[0];
                        }
                    });
                }

                localScope.isVirtualScrollConfigured = false;

                scope.$watch(function () {
                    return scope[attrs.uixPagination];
                }, function (newValue, oldValue) {
                    if (newValue !== oldValue && localScope.isVirtualScroll && !localScope.isVirtualScrollConfigured) {
                        var elem = $(element).prev(),
                            target = elem.get()[0] || { scrollHeight: 0, clientHeight: 0 },
                            hasScrollable = target.scrollHeight > target.clientHeight,
                            scrollTo = localScope.direction == 'up' ? (target.scrollHeight - target.clientHeight - 1) : 1;

                        if (hasScrollable) {
                            $timeout(function () {
                                bindVirtualScrolling();
                            }, 50);
                        }
                    }
                }, true);

                scope.$watch(function () {
                    return localScope.virtualCount;
                }, function (newValue, oldValue) {
                    if (newValue !== oldValue && localScope.pages.length === 0) {
                        localScope.currentPage = 1;
                        localScope.pageRange.end = Math.min(localScope.rangeSize, localScope.pageCount());
                        for (var i = localScope.pageRange.start; i <= localScope.pageRange.end; i++) {
                            localScope.pages.push(i);
                        }
                    }
                }, true);

                scope.$watch(function () {
                    return localScope.selectedPagesize;
                }, function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        unbindVirtualScrolling(function () {
                            localScope.currentPage = 1;
                            localScope.pageRange.start = localScope.currentPage;
                            localScope.pageRange.end = Math.min(localScope.rangeSize, localScope.pageCount());
                            localScope.pages = [];
                            for (var i = localScope.pageRange.start; i <= localScope.pageRange.end; i++) {
                                localScope.pages.push(i);
                            }
                            scope[attrs.selectedPagesize] = newValue;
                            localScope.$emit('onPageSizeChange', newValue);
                            if (onPageSizeChange) {
                                $parse(onPageSizeChange)(scope, { $event: { target: $(element), pageSize: localScope.selectedPagesize, currentPage: localScope.currentPage } });
                            }
                        });
                    }
                }, true);

                scope.$watch(function () {
                    return localScope.currentPage;
                }, function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        if (newValue > oldValue && localScope.currentPage > localScope.pageRange.end && localScope.hasNextPage()) {
                            localScope.pageRange.start = localScope.currentPage;
                            localScope.pageRange.end = Math.min((localScope.currentPage + localScope.rangeSize), localScope.pageCount());
                            localScope.pages = [];
                            for (var i = localScope.pageRange.start; i <= localScope.pageRange.end; i++) {
                                localScope.pages.push(i);
                            }
                        }
                        else if (newValue < oldValue && localScope.currentPage < localScope.pageRange.start && localScope.hasPreviousPage()) {
                            localScope.pageRange.start = ((localScope.currentPage <= localScope.rangeSize) ? 1 : (localScope.currentPage - localScope.rangeSize));
                            localScope.pageRange.end = localScope.currentPage;
                            localScope.pages = [];
                            for (var i = localScope.pageRange.start; i <= localScope.pageRange.end; i++) {
                                localScope.pages.push(i);
                            }
                        }
                        scope[attrs.currentPage] = newValue;
                        localScope.$emit('onPageIndexChange', newValue);
                        if (onPageIndexChange) {
                            $parse(onPageIndexChange)(scope, { $event: { target: $(element), pageSize: localScope.selectedPagesize, currentPage: localScope.currentPage } });
                        }
                    }
                    localScope.isResetting = false;
                }, true);


                $(element).addClass("pagingOptions clearfix");

                function bindVirtualScrolling() {
                    if (attrs.uixPagination !== "" && localScope.isVirtualScroll) {
                        var self = $(element),
                            prev = self.prev(),
                            prevElem = prev.get()[0],
                            scrollHeight = prevElem ? prevElem.scrollHeight : 0,
                            clientHeight = prevElem ? prevElem.clientHeight : 0,
                            isScrollable = clientHeight < scrollHeight,
                            spacerHeight = 0,
                            scrollTimer = null;

                        if (isScrollable) {
                            prevElem.scrollTop = 0;
                            prev.children().each(function (i) {
                                spacerHeight += $(this).height();
                            });
                            spacerHeight = spacerHeight * localScope.pageCount();

                            prev.addClass('vscrollContainer')
                                .append($('<div class="vscrollSpacer"></div>').height(spacerHeight))
                                .children().not('.vscrollSpacer').addClass('vscrollContent');

                            prev
                                .on('mousedown.uixPagination', function () {
                                    localScope.$apply(function () {
                                        localScope.isMouseDown = true;
                                    });
                                })
                                .on('mouseup.uixPagination', function (evt) {
                                    if (scrollTimer) {
                                        $timeout.cancel(scrollTimer);
                                    }
                                    var content = $(evt.target).children('.vscrollContent'),
                                                    contentTop = content.css('top'),
                                                    intTop = contentTop != "" && contentTop != "auto" ? parseInt(contentTop.substr(0, contentTop.indexOf('px'))) : 0,
                                                    scrolledPage = Math.min(Math.max(Math[evt.target.scrollTop < intTop ? 'floor' : 'ceil'](evt.target.scrollTop / content.height()), 1), localScope.pageCount());
                                    if (localScope.currentPage !== scrolledPage) {
                                        localScope.$apply(function () {
                                            localScope.currentPage = scrolledPage;
                                            if (localScope.currentPage == 1) {
                                                evt.target.scrollTop = 0;
                                            }
                                            content.css({ top: evt.target.scrollTop.toString() + 'px' });
                                        });
                                    }
                                    localScope.isMouseDown = false;
                                })
                                .on('scroll.uixPagination', function (evt) {
                                    if (!localScope.isMouseDown) {
                                        if (scrollTimer) {
                                            $timeout.cancel(scrollTimer);
                                        }
                                        if (evt.target.clientHeight < evt.target.scrollHeight) {
                                            scrollTimer = $timeout(function () {
                                                var content = $(evt.target).children('.vscrollContent'),
                                                    contentTop = content.css('top'),
                                                    intTop = contentTop != "" && contentTop != "auto" ? parseInt(contentTop.substr(0, contentTop.indexOf('px'))) : 0,
                                                    isScrolledUp = evt.target.scrollTop < intTop,
                                                    scrolledPage = Math.min(Math.max(Math[isScrolledUp ? 'floor' : 'ceil'](evt.target.scrollTop / content.height()), 1), localScope.pageCount());
                                                if (localScope.currentPage !== scrolledPage) {
                                                    localScope.$apply(function () {
                                                        localScope.currentPage = scrolledPage;
                                                        if (localScope.currentPage == 1) {
                                                            evt.target.scrollTop = 0;
                                                        }
                                                        content.css({ top: evt.target.scrollTop.toString() + 'px' });
                                                    });
                                                }
                                                else if (isScrolledUp) {
                                                    content.css({ top: evt.target.scrollTop.toString() + 'px' });
                                                }
                                            }, 600);
                                        }
                                    }
                                });

                            localScope.isVirtualScrollConfigured = true;

                        }

                    }
                }

                function unbindVirtualScrolling(callback) {
                    var target = $(element),
                        targetElem = target.get()[0],
                        prev = target.prev();

                    targetElem.scrollTop = 0;

                    prev.children('.vscrollSpacer').remove();

                    prev
                        .off('.uixPagination')
                        .removeClass('vscrollContainer')
                        .children().removeClass('vscrollContent')
                        .css({ top: 'auto' });

                    localScope.isVirtualScrollConfigured = false;

                    if (callback) {
                        callback();
                    }
                }

            }
        }


    }]);

    controls.directive('uixDateValidation', ['$filter', function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, element, attrs, ngModel) {
                var expression = attrs.uixDateValidation !== "" ? attrs.uixDateValidation : ((attrs.uixDatepicker && attrs.uixDatepicker != "") ? attrs.uixDatepicker : 'MM/dd/yyyy'),
                    daySectionIndex = -1,
                    mmSectionIndex = -1,
                    ddSectionIndex = -1,
                    yySectionIndex = -1,
                    usesMonthText = false,
                    usesDayOfWeek = false,
                    format = '',
                    pattern = null;

                function convertDayTextToNumber(text) {
                    var value = -1;
                    if (/^mon/i.test(text)) {
                        value = 1;
                    }
                    else if (/^tue/i.test(text)) {
                        value = 2;
                    }
                    else if (/^wed/i.test(text)) {
                        value = 3;
                    }
                    else if (/^thu/i.test(text)) {
                        value = 4;
                    }
                    else if (/^fri/i.test(text)) {
                        value = 5;
                    }
                    else if (/^sat/i.test(text)) {
                        value = 6;
                    }
                    else if (/^sun/i.test(text)) {
                        value = 0;
                    }
                    return value;
                }

                function convertMonthTextToNumber(text) {
                    var value = -1;
                    if (/^jan/i.test(text)) {
                        value = 1;
                    }
                    else if (/^feb/i.test(text)) {
                        value = 2;
                    }
                    else if (/^mar/i.test(text)) {
                        value = 3;
                    }
                    else if (/^apr/i.test(text)) {
                        value = 4;
                    }
                    else if (/^may/i.test(text)) {
                        value = 5;
                    }
                    else if (/^jun/i.test(text)) {
                        value = 6;
                    }
                    else if (/^jul/i.test(text)) {
                        value = 7;
                    }
                    else if (/^aug/i.test(text)) {
                        value = 8;
                    }
                    else if (/^sep/i.test(text)) {
                        value = 9;
                    }
                    else if (/^oct/i.test(text)) {
                        value = 10;
                    }
                    else if (/^nov/i.test(text)) {
                        value = 11;
                    }
                    else if (/^dec/i.test(text)) {
                        value = 12;
                    }
                    return value;
                }

                function canValidateActualDate() {
                    return ((mmSectionIndex > -1) && (ddSectionIndex > -1) && (yySectionIndex > -1));
                }

                function isValidActualDate(viewValue) {
                    if (viewValue === "" || !canValidateActualDate()) return true;
                    var result = true,
                        valueArr = viewValue.split(/[^\w]+/g),
                        mmVal = (usesMonthText ? convertMonthTextToNumber(valueArr[mmSectionIndex]) : (isNaN(valueArr[mmSectionIndex]) ? -1 : parseInt(valueArr[mmSectionIndex]))),
                        ddVal = isNaN(valueArr[ddSectionIndex]) ? -1 : parseInt(valueArr[ddSectionIndex]),
                        yyVal = isNaN(valueArr[yySectionIndex]) ? -1 : parseInt(valueArr[yySectionIndex]),
                        dayVal = usesDayOfWeek ? convertDayTextToNumber(valueArr[daySectionIndex]) : -1,
                        actualDate = new Date(yyVal, (mmVal - 1), ddVal);

                    result = (result && ((actualDate.getMonth() + 1) == mmVal));
                    result = (result && (actualDate.getDate() == ddVal));
                    result = (result && (actualDate.getFullYear() == yyVal));
                    if (usesDayOfWeek) {
                        result = (result && (actualDate.getDay() == dayVal));
                    }
                    return result;
                }

                var formatRegex = {
                    "yyyy": '([0-9]{4})',
                    "yy": '([0-9]{2})',
                    "y": '([0-9]{1,4})',
                    "MMMM": '(january|february|march|april|may|june|july|august|september|october|november|december)',
                    "MMM": '(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)',
                    "MM": '(1[0-2]|0?[1-9])',
                    "M": '(1[0-2]|[1-9])',
                    "dd": '(3[01]|[12][0-9]|0?[1-9])',
                    "d": '(3[01]|[12][0-9]|[1-9])',
                    "EEEE": '(sunday|monday|tuesday|wednesday|thursday|friday|saturday)',
                    "EEE": '(sun|mon|tue|wed|thu|fri|sat)',
                    "HH": '(2[0-4]|1[0-9]|0?[0-9])',
                    "H": '(2[0-4]|1[0-9]|[0-9])',
                    "hh": '(1[0-2]|0?[1-9])',
                    "h": '(1[0-2]|[1-9])',
                    "mm": '([1-6][0-9]|0?[0-9])',
                    "m": '([1-6][0-9]|[0-9])',
                    "ss": '([1-6][0-9]|0?[0-9])',
                    "s": '([1-6][0-9]|[0-9])',
                    "sss": '([0-9]{1,3})',
                    "a": '((a|p)m)',
                    "Z": '([\-\+]?(1200|[01]?[01]?[0-9]{1,2}))'
                }

                function generateTestRegEx() {
                    var expArr = format.replace('/\s/g', ' ').split(""),
                        strLength = expArr.length,
                        section = '',
                        regexStr = '',
                        sectionCounter = 0,
                        i = 0,
                        j = 0;

                    while (i < strLength) {
                        // Check if format characters, not special characters.
                        if (/^[ymdehsaz]/i.test(expArr[i])) {
                            j = format.lastIndexOf(expArr[i]) + 1;
                            section = format.substring(i, j);

                            // Get the index for the year, month, and date to be able to substring input and create a new date on validation
                            if (/^y/.test(section)) {
                                yySectionIndex = sectionCounter;
                            }
                            else if (/^M/.test(section)) {
                                mmSectionIndex = sectionCounter;
                                usesMonthText = /^[M]{3,4}$/.test(section);
                            }
                            else if (/^d/.test(section)) {
                                ddSectionIndex = sectionCounter;
                            }
                            else if (/^E/.test(section)) {
                                daySectionIndex = sectionCounter;
                                usesDayOfWeek = true;
                            }

                            regexStr += formatRegex[section];
                            sectionCounter++;
                        }
                            // Check if character is white space, if so add spaceing regex.
                        else if (/\s/.test(expArr[i])) {
                            regexStr += '\\s+';
                            j++;
                        }
                            // Check if not format character and not spacing, if so, add escape character then special character.
                        else if (/^[^\w^\s]$/.test(expArr[i])) {
                            regexStr += '\\'.concat(expArr[i]);
                            j++;
                        }

                        i = j;
                    }

                    return new RegExp('^\s*$|^' + regexStr + '$', ['i']);
                }

                if (/^medium$/i.test(expression)) {
                    format = 'MMM d, y h:mm:ss a';
                }
                else if (/^mediumDate$/i.test(expression)) {
                    format = 'MMM d, y';
                }
                else if (/^mediumTime$/i.test(expression)) {
                    format = 'h:mm:ss a';
                }
                else if (/^short$/i.test(expression)) {
                    format = 'M/d/yy h:mm a';
                }
                else if (/^shortDate$/i.test(expression)) {
                    format = 'M/d/yy';
                }
                else if (/^shortTime$/i.test(expression)) {
                    format = 'h:mm a';
                }
                else if (/^fullDate$/i.test(expression)) {
                    format = 'EEEE, MMMM d, y'
                }
                else if (/^longDate$/i.test(expression)) {
                    format = 'MMMM d, y'
                }
                else {
                    format = expression;
                }

                pattern = generateTestRegEx();

                ngModel.$formatters.unshift(function (modelValue) {
                    return (modelValue) ? $filter('date')(modelValue, format) : '';
                });
                ngModel.$parsers.unshift(function (viewValue) {
                    if (pattern.test(viewValue) && isValidActualDate(viewValue)) {

                        element.removeClass('has-error error');
                        ngModel.$setValidity('date', true);
                        return viewValue !== "" ? new Date(viewValue) : undefined;
                    } else {
                        element.addClass('has-error error');
                        ngModel.$setValidity('date', false);
                        return undefined;

                    }
                });
                element.off('input').off('keydown').off('change')
                    .on('blur.uixDateValidation', function () {
                        scope.$apply(function () {
                            ngModel.$setViewValue(element.val());
                        });
                    })
                    .on('$destroy', function () {
                        $(this).off('.uixDateValidation');
                    });
            }
        };
    }]);

    controls.directive('uixCurrencyValidation', ['$filter', function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, elem, attrs, ctrl) {
                var symbol = attrs.uixCurrencyValidation ? attrs.uixCurrencyValidation : '$',
                    pattern = new RegExp('^$|^\\(?[\\' + symbol + '\\-]{0,2}([0-9]+|([0-9]{0,3})(,[0-9]{3})*)(\\.[0-9]{2})?\\)?$');


                ctrl.$formatters.push(function (modelValue) {
                    elem.css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                    return (modelValue) ? $filter('currency')(modelValue, symbol) : '';
                });
                ctrl.$parsers.unshift(function (viewValue) {
                    elem.css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                    if (pattern.test(viewValue)) {
                        elem.removeClass('has-error error');
                        ctrl.$setValidity('currency', true);
                        var strValue = viewValue.substr(viewValue.indexOf(symbol) + 1).replace(/[,\)]/g, '');
                        if (strValue.length > 0 && (ctrl.$modelValue < 0 || viewValue.indexOf(')') > 0) && strValue.indexOf('-') < 0) {
                            strValue = '-' + strValue;
                        }
                        return parseFloat(strValue) || '';
                    } else {
                        elem.addClass('has-error error');
                        ctrl.$setValidity('currency', false);
                        return undefined;
                    }
                });
                elem
                    .on('blur.uixCurrencyValidation', function () {
                        $(this).css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                        ctrl.$setViewValue($filter('currency')(ctrl.$modelValue, symbol));
                        ctrl.$render();
                    })
                    .on('$destroy', function () {
                        $(this).off('.uixCurrencyValidation');
                    });
            }
        };
    }]);

    controls.directive('uixNumberValidation', ['$filter', function ($filter) {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, elem, attrs, ctrl) {
                var decimalPlaces = (attrs.uixNumberValidation && !isNaN(attrs.uixNumberValidation)) ? parseInt(attrs.uixNumberValidation) : 0,
                    pattern = new RegExp('^$|^-?([0-9]+|([0-9]{0,3})(,[0-9]{3})*)(\\.[0-9]{0,' + decimalPlaces + '})?$');

                ctrl.$formatters.push(function (modelValue) {
                    elem.css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                    return (modelValue) ? $filter('number')(modelValue, decimalPlaces) : '';
                });
                ctrl.$parsers.unshift(function (viewValue) {
                    elem.css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                    if (pattern.test(viewValue)) {
                        elem.removeClass('has-error error');
                        ctrl.$setValidity('number', true);
                        return parseFloat(viewValue.replace(/,/g, '')) || '';
                    } else {
                        elem.addClass('has-error error');
                        ctrl.$setValidity('number', false);
                        return undefined;
                    }
                });

                elem
                    .on('blur.uixNumberValidation', function () {
                        $(this).css({ 'color': ctrl.$modelValue < 0 ? 'red' : 'inherit' });
                        ctrl.$setViewValue($filter('number')(ctrl.$modelValue, decimalPlaces));
                        ctrl.$render();
                    })
                    .on('$destroy', function () {
                        $(this).off('.uixNumberValidation');
                    });
            }
        };
    }]);

    controls.directive('uixDatepicker', ['$filter', '$compile', function ($filter, $compile) {
        return {
            restrict: 'A',
            require: 'ngModel',
            replace: false,
            //template: '<input type="text" uix-date-validation />',
            link: function (scope, element, attrs, ngModel) {
                if (!ngModel) {
                    throw new Error("ngModel directive is required.");
                    return;
                }

                if (!$.ui) {
                    throw new Error("jQuery UI is required for this directive.");
                    return;
                }

                var expression = attrs.uixDatepicker !== "" ? attrs.uixDatepicker : 'MM/dd/yyyy',
                    options = { dataFormat: "m/d/yy" },
                    format = '';

                function generateJqueryFormat() {
                    var expArr = format.replace('/\s/g', ' ').split(""),
                        strLength = expArr.length,
                        section = '',
                        jqFormatStr = '',
                        i = 0,
                        j = 0;

                    while (i < strLength) {
                        // Check if format characters, not special characters.
                        if (/^[ymde]/i.test(expArr[i])) {
                            j = format.lastIndexOf(expArr[i]) + 1;
                            section = format.substring(i, j);

                            // Get the index for the year, month, and date to be able to substring input and create a new date on validation
                            if (/^[y]{2}$/.test(section)) {
                                jqFormatStr += 'y';
                            }
                            else if (/^([y]{1}|[y]{4})$/.test(section)) {
                                jqFormatStr += 'yy';
                            }
                            else if (/^[M]{4}$/.test(section)) {
                                jqFormatStr += 'MM';
                            }
                            else if (/^[M]{3}$/.test(section)) {
                                jqFormatStr += 'M';
                            }
                            else if (/^[M]{2}$/.test(section)) {
                                jqFormatStr += 'mm';
                            }
                            else if (/^[M]{1}$/.test(section)) {
                                jqFormatStr += 'm';
                            }
                            else if (/^[d]{2}$/.test(section)) {
                                jqFormatStr += 'dd';
                            }
                            else if (/^[d]{1}$/.test(section)) {
                                jqFormatStr += 'd';
                            }
                            else if (/^[E]{4}$/.test(section)) {
                                jqFormatStr += 'DD';
                            }
                            else if (/^[E]{3}$/.test(section)) {
                                jqFormatStr += 'D';
                            }
                        }
                            // Check if character is white space, if so add spaceing.
                        else if (/\s/.test(expArr[i])) {
                            jqFormatStr += ' ';
                            j++;
                        }
                            // Check if not format character and not spacing, if so, add escape character then special character.
                        else if (/^[^\w^\s]$/.test(expArr[i])) {
                            jqFormatStr += expArr[i];
                            j++;
                        }

                        i = j;
                    }

                    return jqFormatStr;
                }

                if (/^mediumDate$/i.test(expression)) {
                    format = 'MMM d, y';
                }
                else if (/^shortDate$/i.test(expression)) {
                    format = 'M/d/yy';
                }
                else if (/^fullDate$/i.test(expression)) {
                    format = 'EEEE, MMMM d, y'
                }
                else if (/^longDate$/i.test(expression)) {
                    format = 'MMMM d, y'
                }
                else {
                    format = expression;
                }

                options.dateFormat = generateJqueryFormat();

                options.onSelect = function (dateText, dpObj) {
                    $(element).focus();
                    scope.$apply(function () {
                        ngModel.$setViewValue(dateText);
                    });
                };

                element.datepicker(options);

                $(element).on('$destroy', function () {
                    $(this).off('.uixDatepicker').datepicker('destroy');
                });


            }
        };

    }]);

    controls.directive('uixDraggable', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                var onDragStart = attr.onDragStart,
                    onDragStop = attr.onDragStop;

                if (!$.ui) {
                    throw new Error("jQuery UI is required for this directive.");
                    return;
                }

                $(element).data('uixDraggable', { dataItem: scope[attr.uixDraggable] });

                $(element).draggable({
                    appendTo: 'body',
                    helper: 'clone',
                    start: function (evt, ui) {
                        scope.$apply(function () {
                            var self = $(evt.target),
                                targets = [];
                            targets.push(self);
                            scope.$parent.draggingItems = [];
                            scope.$parent.draggingItems.push(self.data('uixDraggable').dataItem);
                            if (!self.hasClass('selected')) {
                                self.addClass('selected')

                            }
                            self.siblings().filter('.selected')
                                .each(function () {
                                    var sib = $(this);
                                    targets.push(sib);
                                    scope.$parent.draggingItems.push(sib.data('uixDraggable').dataItem);
                                    sib.clone().appendTo($('body')).addClass('draggingClone');
                                });

                            if (onDragStart && onDragStart !== '') {
                                $parse(onDragStart)(scope, { $event: { target: self, dataItem: self.draggable('option', 'dataItem'), draggingItems: scope.$parent.draggingItems, draggingTargets: targets } });
                            }
                        });
                    },
                    drag: function (evt, ui) {
                        var height = $(evt.target).height();
                        $('.draggingClone').each(function (i) {
                            $(this).css({ top: (ui.position.top + height * (i + 1)), left: ui.position.left });
                        });
                    },
                    stop: function (evt, ui) {
                        var self = $(evt.target),
                            targets = [];
                        targets.push(self);
                        self.removeClass('selected')
                            .siblings().filter('.selected').removeClass('selected').each(function () {
                                var sib = $(this);
                                targets.push(sib);
                            });
                        $('.draggingClone').remove();
                        if (onDragStop && onDragStop !== '') {
                            scope.$apply(function () {
                                $parse(onDragStop)(scope, { $event: { target: self, dataItem: self.draggable('option', 'dataItem'), draggingItems: scope.$parent.draggingItems, draggingTargets: targets } });
                            });
                        }
                    }
                });

                $(element).on('$destroy', function () {
                    $(this).draggable('destroy');
                });

            }
        }
    }]);

    controls.directive('uixDroppable', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                var options = {
                    hasOnDrop: attr.onDrop !== undefined && attr.onDrop !== "",
                    dataItem: scope[attr.uixDroppable],
                    onDrop: attr.onDrop
                };

                if (!$.ui) {
                    throw new Error("jQuery UI is required for this directive.");
                    return;
                }

                $(element).data('uixDroppable', options).droppable({
                    tolerance: 'pointer',
                    greedy: true,
                    hoverClass: 'hover',
                    drop: function (evt, ui) {
                        var self = $(this),
                            opts = self.data('uixDroppable');
                        if (opts.hasOnDrop) {
                            scope.$apply(function () {
                                $parse(opts.onDrop)(scope, { $event: { target: evt.target, dataItem: opts.dataItem, droppedItems: scope.draggingItems } });
                            });
                        }
                        $(evt.target).removeClass('hover');
                    }
                });

                $(element).on('$destroy', function () {
                    $(this).droppable('destroy');
                });
            }
        };
    }]);

    controls.directive('uixHoverable', [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                if (!$(element).hasClass('hoverable')) {
                    $(element).addClass('hoverable');
                }
            }
        };
    }]);

    controls.directive('uixSelectable', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                var options = {
                    isMultiple: false,
                    hasScopeCollection: attr.selectedItems !== undefined,
                    hasOnSelect: attr.onSelect !== undefined,
                    hasOnDeselect: attr.onDeselect !== undefined,
                    hasDataItem: attr.uixSelectable !== undefined && attr.uixSelectable !== "",
                    scopeCollection: attr.selectedItems,
                    dataItem: scope[attr.uixSelectable],
                    onSelect: attr.onSelect,
                    onDeselect: attr.onDeselect
                };

                if (attr.enableMultiple && attr.enableMultiple !== "") {
                    scope.$watch(function () {
                        return scope[attr.enableMultiple] !== undefined ? scope[attr.enableMultiple] : scope.$eval(attr.enableMultiple) === true;
                    },
                    function (newValue) {
                        var elem = $(element),
                            data = elem.data('uixSelectable');
                        data.isMultiple = newValue;

                        if (newValue == false && !elem.hasClass('prevSelected')) {
                            elem.removeClass('selected');
                            removeItemFromCollection(data.dataItem);
                        }
                    });
                }

                function addItemToCollection(item) {
                    if (item !== undefined) {
                        var collLength = scope[options.scopeCollection] ? scope[options.scopeCollection].length : 0,
                            j = 0,
                            found = false;
                        while (j < collLength && !found) {
                            found = scope[options.scopeCollection][j] === item;
                            j++;
                        }

                        if (!found) {
                            scope[options.scopeCollection].push(item);
                        }
                    }
                }

                function removeItemFromCollection(item) {
                    if (item !== undefined) {
                        var collLength = scope[options.scopeCollection] ? scope[options.scopeCollection].length : 0,
                            j = 0;
                        while (j < collLength) {
                            if (scope[options.scopeCollection][j] === item) {
                                scope[options.scopeCollection].splice(j, 1);
                                break;
                            }
                            j++;
                        }
                    }
                }

                $(element).data('uixSelectable', options)
                    .on('click.uixSelectable', function (evt) {
                        var self = $(this),
                            target = $(evt.target),
                            opts = self.data('uixSelectable'),
                            isSelected = target.hasClass('selected');

                        scope.$apply(function () {
                            if (isSelected) {
                                if (opts.isMultiple) {
                                    if (evt.shiftKey) {
                                        if (target.prevAll().hasClass('prevDeselected')) {
                                            target.prevUntil('.prevDeselected').each(function () {
                                                var sib = $(this);
                                                sib.removeClass('selected');
                                                removeItemFromCollection(sib.data('uixSelectable').dataItem);
                                            });
                                        }
                                        else if (target.nextAll().hasClass('prevDeselected')) {
                                            target.nextUntil('.prevDeselected').each(function () {
                                                var sib = $(this);
                                                sib.removeClass('selected');
                                                removeItemFromCollection(sib.data('uixSelectable').dataItem);
                                            });
                                        }
                                    }
                                    target.removeClass('selected prevSelected').addClass('prevDeselected').siblings().removeClass('prevDeselected');

                                    if (opts.hasScopeCollection && opts.hasDataItem) {
                                        removeItemFromCollection(opts.dataItem);
                                    }
                                }
                                else {
                                    target.removeClass('selected prevSelected').addClass('prevDeselected');

                                    if (opts.hasScopeCollection && opts.hasDataItem) {
                                        if (scope[opts.scopeCollection].length > 0) {
                                            scope[opts.scopeCollection].pop();
                                        }
                                    }
                                }

                                if (opts.hasOnDeselect) {
                                    $parse(opts.onDeselect)(scope, { $event: { dataItem: opts.dataItem, target: target } });
                                }
                            }
                            else {
                                if (opts.isMultiple) {
                                    if (evt.shiftKey) {
                                        if (target.prevAll().hasClass('prevSelected')) {
                                            target.prevUntil('.prevSelected').each(function () {
                                                var sib = $(this);
                                                sib.addClass('selected');
                                                if (opts.hasScopeCollection && opts.hasDataItem) {
                                                    addItemToCollection(sib.data('uixSelectable').dataItem);
                                                }
                                            });
                                        }
                                        else if (target.nextAll().hasClass('prevSelected')) {
                                            target.nextUntil('.prevSelected').each(function () {
                                                var sib = $(this);
                                                sib.addClass('selected');
                                                if (opts.hasScopeCollection && opts.hasDataItem) {
                                                    addItemToCollection(sib.data('uixSelectable').dataItem);
                                                }
                                            });
                                        }
                                    }

                                    if (opts.hasScopeCollection && opts.hasDataItem) {
                                        addItemToCollection(opts.dataItem);
                                    }
                                    target.addClass('selected prevSelected').siblings().removeClass('prevSelected');
                                }
                                else {
                                    target.addClass('selected').siblings().removeClass('selected');
                                    if (opts.hasScopeCollection && opts.hasDataItem) {
                                        if (scope[opts.scopeCollection].length > 0) {
                                            scope[opts.scopeCollection].pop();
                                        }
                                        scope[opts.scopeCollection].push(opts.dataItem);
                                    }
                                }
                                if (opts.hasOnSelect) {
                                    $parse(opts.onSelect)(scope, { $event: { dataItem: opts.dataItem, target: target } });
                                }

                            }
                        });
                    })
                    .on('$destroy', function () {
                        $(this).off('.uixSelectable').data('uixSelectable', null);
                    });
            }
        }
    }]);

    //controls.directive('uixSortable', ['$parse', '$filter', function ($parse, $filter) {
    //    return {
    //        restrict: 'A',
    //        link: function (scope, element, attr) {
    //            var ele = $(element),
    //                hasCollection = attr.uixSortable !== "",
    //                collection = ele.data('uixSortableCollection', { collection: [] }).data('uixSortableCollection'),
    //                dataField = attr.field,
    //                onSort = attr.onSort,
    //                isMultipleFields = false,
    //                canSort = true,
    //                ascImg = $('<div class="sortImage ascSortImage"><span class="glyphicon glyphicon-chevron-up"></span></div>'),
    //                descImg = $('<div class="sortImage descSortImage"><span class="glyphicon glyphicon-chevron-down"></span></div>');

    //            if (ele.css('textAlign') == 'left') {
    //                ele.css({ paddingLeft: '25px' });
    //                ascImg.css({ marginLeft: '-15px' });
    //                descImg.css({ marginLeft: '-15px' });
    //            }


    //            if (attr.enableMultiple && attr.enableMultiple !== "") {
    //                scope.$watch(function () {
    //                    return scope[attr.enableMultiple] !== undefined ? scope[attr.enableMultiple] : scope.$eval(attr.enableMultiple) === true;
    //                },
    //                function (newValue) {
    //                    var elem = $(element),
    //                        data = elem.data('uixSortable');
    //                    data.isMultipleFields = newValue;

    //                    if (newValue == false && data.priority > 0) {
    //                        data.sortDirection = '';
    //                        data.priority = -1;
    //                        elem.children('.sortImage').fadeOut();
    //                    }
    //                });
    //            }

    //            if (attr.enableSort && attr.enableSort !== "") {
    //                scope.$watch(function () {
    //                    return scope[attr.enableSort] !== undefined ? scope[attr.enableSort] : scope.$eval(attr.enableSort) === true;
    //                },
    //                function (newValue) {
    //                    canSort = newValue;

    //                });
    //            }

    //            scope.$watch(function () { return scope[attr.uixSortable]; },
    //                function (value) {
    //                    if (hasCollection) {
    //                        collection = value;
    //                    }
    //                }, true);


    //            ele.addClass('sortable')
    //                .data('uixSortable', { field: dataField, sortDirection: '', priority: -1, isMultipleFields: false })
    //                .prepend(ascImg)
    //                .prepend(descImg)
    //                .on('click.uixSortable', function (evt) {
    //                    sort($(this));
    //                })
    //                .on('$destroy', function () {
    //                    $(this).off('.uixSortable').data('uixSortable', null).data('uixSortableCollection', null);
    //                });


    //            function sort(elem) {
    //                var opts = elem.data('uixSortable') || {},
    //                    isMultiple = opts.isMultipleFields,
    //                    prevDirection = opts.sortDirection || '',
    //                    isAscending = prevDirection === 'asc',
    //                    isDescending = prevDirection === 'desc',
    //                    sibs = elem.siblings('.sortable'),
    //                    sorts = [],
    //                    length = 0,
    //                    i = 0;

    //                if (isMultiple) {
    //                    sibs.each(function () {
    //                        var sib = $(this),
    //                            sibOpts = sib.data('uixSortable'),
    //                            canAdd = sibOpts.sortDirection !== '';
    //                        if (canAdd) {
    //                            sorts.push($(this).data('uixSortable'));
    //                        }
    //                    });
    //                    sorts.sortBy('priority');
    //                    length = sorts.length;
    //                    while (i < length) {
    //                        sorts[i].priority = i;
    //                        i++;
    //                    }
    //                    opts.priority = sorts.length;
    //                    sorts.push(opts);
    //                }
    //                else {
    //                    opts.priority = 0
    //                    sorts.push(opts);
    //                    sibs.each(function () {
    //                        var sib = $(this);
    //                        sib.data('uixSortable').sortDirection = '';
    //                        $(this).children('.sortImage').fadeOut();
    //                    });
    //                }

    //                if (!isAscending && !isDescending) {
    //                    opts.sortDirection = 'asc';
    //                    elem.children('.ascSortImage').fadeIn(200, function () {

    //                    });
    //                }
    //                else if (isAscending) {
    //                    opts.sortDirection = 'desc';
    //                    elem.find('.ascSortImage').fadeOut(200, function () {
    //                        elem.children('.descSortImage').fadeIn(200);

    //                    });
    //                }
    //                else {
    //                    opts.sortDirection = '';
    //                    elem.children('.sortImage').fadeOut(200, function () {

    //                    });
    //                }

    //                scope.$apply(function () {
    //                    if (onSort && onSort !== "") {
    //                        $parse(onSort)(scope, { $event: { target: elem, sorts: sorts } });
    //                    }
    //                    if (canSort) {
    //                        var sortsLength = sorts.length,
    //                            j = 0,
    //                            pred = '';
    //                        while (j < sortsLength && sorts[j].sortDirection !== '') {
    //                            pred += sorts[j].sortDirection === 'desc' ? '-'.concat(sorts[j].field) : '+'.concat(sorts[j].field);
    //                            j++;
    //                        }

    //                        scope[attr.uixSortable] = $filter('orderBy')(scope[attr.uixSortable], pred);
    //                    }
    //                });
    //            }
    //        }

    //    };
    //}]);

    controls.directive('uixListview', [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                if (!element.hasClass('listview')) {
                    element.addClass('listview');
                }
            }
        }
    }]);

    controls.directive('uixTreeview', [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                if (!element.hasClass('treeview')) {
                    element.addClass('treeview');
                }
            }
        }
    }]);

    controls.directive('uixTreenode', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                var data = scope[attr.uixTreenode],
                    optIsCollapsed = scope.$eval(attr.isLeaf) === true || scope.$eval(attr.isCollapsed) === true,
                    optIsLeaf = scope.$eval(attr.isLeaf) === true,
                    onExpand = attr.onExpand,
                    onCollapse = attr.onCollapse;

                if (element.is('li')) {
                    configureNode(element, optIsCollapsed, optIsLeaf, scope[attr.uixTreenode]);
                }

                function configureNode(li, isCollapsed, isLeaf, data) {
                    var self = $(li),
                        html = '<div class="horizontalguide"></div><div class="verticalguide"></div>',
                        obj = {};

                    if (!isLeaf) {
                        html = html.concat(isCollapsed
                            ? '<span class="glyphicon glyphicon-expand"></span>'
                            : '<span class="glyphicon glyphicon-collapse-down"></span>');
                    }

                    obj = angular.element(html);

                    self.addClass(isLeaf ? 'treenode treeleaf' : 'treenode')
                        .prepend(obj);
                    if (!isLeaf) {
                        self.data('uixTreenode', { isCollapsed: isCollapsed, dataItem: data })
                        .on('click.uixTreenode', function (evt) {
                            evt.stopPropagation();
                            var clickedItem = $(this),
                                isCollapsed = clickedItem.data('uixTreenode').isCollapsed,
                                iconSpan = clickedItem.children('span.glyphicon'),
                                verticalguide = clickedItem.children('div.verticalguide'),
                                list = clickedItem.children('ul').first();

                            if (isCollapsed) {
                                iconSpan.removeClass('glyphicon-expand').addClass('glyphicon-collapse-down');
                                verticalguide.fadeIn();
                                list.slideDown(400, function () {
                                    clickedItem.removeClass('expanding').addClass('expanded').trigger('treenode-expand.uixTreenode');
                                    if (onExpand) {
                                        scope.$apply(function () {
                                            $parse(onExpand)(scope, { $event: { target: clickedItem, dataItem: clickedItem.data('uixTreenode').dataItem } });
                                        });
                                    }
                                });
                                clickedItem.addClass('expanding').removeClass('collapsed');
                            }
                            else {
                                iconSpan.removeClass('glyphicon-collapse-down').addClass('glyphicon-expand');
                                verticalguide.fadeOut();
                                list.slideUp(400, function () {
                                    clickedItem.addClass('collapsed').trigger('treenode-collapse.uixTreenode');
                                    if (onCollapse) {
                                        scope.$apply(function () {
                                            $parse(onCollapse)(scope, { $event: { target: clickedItem, dataItem: clickedItem.data('uixTreenode').dataItem } });
                                        });
                                    }

                                });
                                clickedItem.removeClass('expanded');
                            }

                            clickedItem.data('uixTreenode').isCollapsed = !isCollapsed;
                        });
                    }
                    else {
                        self.on('click.uixTreenode', function (evt) {
                            evt.stopPropagation();
                        });
                    }

                    if (isCollapsed) {
                        self.find('div.verticalguide').first().hide();
                        self.find('ul').first().hide();
                    }
                    else {
                        self.find('div.verticalguide').first().show();
                        self.find('ul').first().show();
                    }

                    self.addClass('lastitem').prevAll('li').removeClass('lastitem');

                    self.on('$destroy', function () {
                        $(this).off('.uixTreenode').data('uixTreenode', null);
                    });
                }
            }
        };
    }]);

    controls.directive('uixContextmenu', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: 'ngModel',
            replace: false,
            link: function (scope, element, attr, ngModel) {
                var menuOptions = $(element).data('uixContextmenu', []).data('uixContextmenu'),
                    obj = scope.$eval(attr.uixContextmenu),
                    dataItem = scope.$eval(attr.ngModel.split('.')[0]),
                    modelValue = ngModel.$modelValue,
                    hasMenu = $('.context-menu').length == 1,
                    menu = hasMenu ? $('.context-menu') : $(document.createElement('div')).addClass('dropdown-menu context-menu absPosList').appendTo('body'),
                    list = hasMenu ? menu.find('ul') : $(document.createElement('ul')).appendTo(menu),
                    itemTemplate = $(document.createElement('li'));


                scope.$watch(function () { return obj; }, function (value) {
                    menuOptions = value;
                }, true);

                function addItems() {
                    var length = menuOptions.length,
                        i = 0;

                    menu.find('li').off('.uixContextmenu').remove();

                    while (i < length) {
                        var item = itemTemplate.clone().html(menuOptions[i].text),
                            args = {
                                menu: menu,
                                func: menuOptions[i].action,
                                item: dataItem,
                                model: ngModel.$modelValue
                            };

                        list.append(item);

                        item
                            .on('click.uixContextmenu', args, function (evt) {
                                scope.$apply(function () {
                                    $parse(evt.data.func)(scope, { $event: { target: element, dataItem: evt.data.item, modelValue: evt.data.model } });
                                });
                                evt.data.menu.slideUp();
                            })
                            .on('$destroy', function () {
                                $(this).off('.uixContextmenu');
                            });

                        i++;
                    }
                }

                $(element).addClass('uixContextmenu')
                .on('contextmenu.uixContextmenu', function (evt) {
                    evt.preventDefault();
                    evt.stopPropagation();
                    if (menu.is(':visible')) {
                        menu.slideUp(250, function () {
                            addItems();
                            menu.css({ 'left': evt.pageX, 'top': evt.pageY }).slideDown();
                        });
                    }
                    else {
                        addItems();
                        menu.css({ 'left': evt.pageX, 'top': evt.pageY }).slideDown();
                    }
                    return false;
                });

                var events = $._data($('body').get()[0], "events"),
                    hasContextmenuHandler = false,
                    clickEvents = events.click || [],
                    length = clickEvents.length,
                    i = 0;

                while (i < length && !hasContextmenuHandler) {
                    hasContextmenuHandler = clickEvents[i].namespace == 'uixContextmenu';
                    i++;
                }

                if (!hasContextmenuHandler) {
                    $('body').on('click.uixContextmenu, contextmenu.uixContextmenu', function (evt) {
                        menu.slideUp();
                    });
                }
            }
        }
    }]);


    controls.directive('uixDropdown', ['$parse', '$filter', '$timeout', '$compile', '$q', function ($parse, $filter, $timeout, $compile, $q) {
        return {
            restrict: 'A',
            replace: false,
            require: 'ngModel',
            scope: {

            },
            template: '<div class="input-group"><textarea class="form-control uixDropdown-input" rows="1" ' +
                'uix-loading-inline="loadingOnDemand" ' +
                'ng-keydown="keydowned($event)" ' +
                'ng-keyup="keyuped($event)" ' +
                'ng-focus="focused($event)" ' +
                'ng-blur="blurred($event)" ' +
                'ng-click="clicked($event)" ' +
                'ng-mousedown="mousedowned($event)">' +
                '</textarea>' +
                '<div ng-show="showButton" class="input-group-btn"><button type="button" tabindex="-1" class="btn btn-default" ng-blur="blurred($event)" ng-click="dropdownButtonClicked($event)"><span class="caret"></span></button></div></div>',
            link: function (localScope, element, attr, ngModel) {
                //0000111110000000002222000000000000003333000000000000004444444444444440000000000555500000006666660000
                var pattern = /^\s*(.*?)(?:\s+as\s+(.*?))?\s+for\s+([\$\w][\$\w]*)(?:\s+in\s+([\$\w][.\$\w]*))(?:\s*\|\s*(.*?)\s*(?::(.*?))?)?$/,
                    hasDropdown = $('.uixDropdown-menu').length > 0,
                    selectedClassName = 'selected',
                    textarea = element.find('textarea'),
                    textareaPadding = (parseInt((textarea.css('paddingTop').replace(/[a-z]/ig, ''))) * 2 + 2),
                    textareaPaddingRight = (parseInt((textarea.css('paddingRight').replace(/[a-z]/ig, '')))),
                    textareaLineHeight = parseInt((textarea.css('lineHeight').replace(/[a-z]/ig, ''))),
                    textareaFontWidth = Math.floor(parseInt((textarea.css('fontSize').replace(/[a-z]/ig, ''))) * .56),
                    enableStrictText = localScope.$parent.$eval(attr.strictText) === true,
                    isResizeable = localScope.$parent.$eval(attr.resizeable) === true,
                    allowText = attr.editable === undefined || localScope.$parent.$eval(attr.editable) === true,
                    isMultipleSelect = localScope.$parent.$eval(attr.enableMultiple) === true,
                    multiSelectDelimiter = attr.delimiter != undefined ? attr.delimiter.toString().concat(' ') : ', ',
                    delimiterPattern = isMultipleSelect ? new RegExp('\\' + multiSelectDelimiter.replace(/\s/g, '') + '\\s{0,1}$') : null,
                    useCheckbox = localScope.$parent.$eval(attr.useCheckbox) === true,
                    hasCustomHeight = attr.height !== undefined,
                    hasCustomWidth = attr.width !== undefined,
                    customHeight = hasCustomHeight ? (parseInt(attr.height.replace(/[a-z]/ig, ''))) : -1,
                    customWidth = hasCustomWidth ? (parseInt(attr.width.replace(/[a-z]/ig, ''))) : -1,
                    onFocusFunc = attr.onFocus,
                    onChangeFunc = attr.onChange,
                    dataExpression = attr.uixDropdown,
                    match = dataExpression.match(pattern);

                if (!match) {
                    throw new Error("Data expression must be in the format of \"_select_ (as _label_)? for (_key_,)?_value_ in _collection_\"\n" +
                        "Example: \"item.valueField as item.textField for item in dataitems\" with an optional filter if needed.");
                }

                var textField = match[2].substr(match[2].indexOf('.') + 1),
                    valueField = match[1] && match[1] !== '' ? (match[1].indexOf('.') > -1 ? match[1].substr(match[1].indexOf('.') + 1) : null) : (match[2].indexOf('.') > -1 ? match[2].substr(match[2].indexOf('.') + 1) : null),
                    collection = match[4],
                    filterName = match[5],
                    hasFilter = filterName && filterName !== '',
                    filterArg = match[6];

                element.addClass('uixDropdown');

                localScope.dataItems = [];
                localScope.selectedIndex = -1;
                localScope.isSingleLine = !isResizeable;
                localScope.loadingOnDemand = false;
                localScope.isTarget = false;
                localScope.showButton = attr.showButton == undefined || attr.showButton.toLowerCase() === "true";

                if (!allowText) {
                    textarea.attr('readonly', 'readonly');
                }

                if (!isResizeable) {
                    textarea.addClass('single-line');
                }


                if (localScope.$parent[attr.ngModel] == undefined) {
                    if (isMultipleSelect) {
                        localScope.$parent[attr.ngModel] = [];
                    }
                    else {
                        localScope.$parent[attr.ngModel] = null;
                    }
                }

                if (!hasDropdown) {
                    var selector = '<div class="absPosList uixDropdown-menu" ng-mousedown="_absPosListClicked($event)" >' +
                        '<ul><li ' +
                            'ng-repeat="item in _absPosList.items" ' +
                            'ng-class="{ ' + selectedClassName + ': item._absPosSelected && !_absPosList.useCheckbox, empty: item._absPosEmptyItem, keyscroll: item._absPosKeyScrolled }" ' +
                            'ng-click="_absPosItemClicked($event, item)" >' +
                            '<div class="checkbox" ng-show="_absPosList.useCheckbox"><label><input type="checkbox" ng-model="item._absPosSelected" ng-click="_absPosItemClicked($event)"> {{ item.' + textField + ' }}</label></div>' +
                            '<div ng-show="!_absPosList.useCheckbox">{{ item.' + textField + ' }}</div>' +
                            '</li></ul></div>';
                    var ddElement = $(selector)
                        .appendTo($('*[ng-app]').on('mousedown.uixDropdown', function (evt) {
                            localScope.$root.$apply(function () {
                                hideDropdown();
                                //if (localScope.$root._absPosList.canClose && !localScope.$root._absPosList.isItemClick) {
                                //    console.log('container click');
                                //    hideDropdown();
                                //}
                                localScope.$root._absPosList.canClose = true;
                                localScope.$root._absPosList.isItemClick = false;
                            });
                        })).css({ maxHeight: 0 }).hide();

                    $compile(ddElement)(localScope.$root);

                    localScope.$root._absPosList = {
                        items: [],
                        focusTimer: null,
                        isRightClick: false,
                        isItemClick: false,
                        canClose: true,
                        canOpen: true,
                        useCheckbox: false,
                        isClosing: false,
                        isClosed: true,
                        isOpening: false,
                        isOpened: false,
                        height: -1,
                        width: -1,
                        targetTextarea: null,
                        getPosition: function () {
                            var dd = $('.uixDropdown-menu'),
                                parent = localScope.$root._absPosList.targetTextarea.parents()
                                    .filter(function () {
                                        return (this.clientHeight < this.scrollHeight || this.clientWidth < this.scrollWidth);
                                    }).first(),
                                taHeight = localScope.$root._absPosList.targetTextarea.outerHeight(),
                                bodyElem = $('body').get()[0],
                                ddHeight = localScope.$root._absPosList.height > 0 ? localScope.$root._absPosList.height : 265,
                                ddWidth = localScope.$root._absPosList.width > 0 ? localScope.$root._absPosList.width : localScope.$root._absPosList.targetTextarea.outerWidth(),
                                offsetLeft = localScope.$root._absPosList.targetTextarea && localScope.$root._absPosList.targetTextarea.length > 0 ? localScope.$root._absPosList.targetTextarea.offset().left : 0,
                                offsetTop = localScope.$root._absPosList.targetTextarea && localScope.$root._absPosList.targetTextarea.length > 0 ? localScope.$root._absPosList.targetTextarea.offset().top : 0,
                                rightOutOfBounds = (offsetLeft + ddWidth - bodyElem.clientWidth),
                                topPos = (offsetTop + taHeight),
                                leftPos = rightOutOfBounds > 0 ? Math.floor(offsetLeft - rightOutOfBounds) : offsetLeft,
                                inViewport = null;

                            if (parent && parent.length > 0) {
                                var pEle = parent.get()[0],
                                    scrollTop = parent.scrollTop(),
                                    scrollLeft = parent.scrollLeft(),
                                    topViewable = parent.offset().top,
                                    leftViewable = parent.offset().left,
                                    bottomViewable = topViewable + pEle.clientHeight + scrollTop,
                                    rightViewable = leftViewable + pEle.clientWidth + scrollLeft;

                                inViewport = ((topViewable < topPos) && (topPos < bottomViewable) && (leftViewable < leftPos) && (leftPos < rightViewable));
                            }

                            return { left: leftPos, top: topPos, height: ddHeight, width: ddWidth, inViewport: inViewport };
                        },
                        reposition: function () {
                            var dd = $('.uixDropdown-menu'),
                                ddIsVisible = dd.is(':visible'),
                                info = localScope.$root._absPosList.getPosition();

                            if (info) {
                                localScope.$root._absPosList.bindScroll();
                                dd.css({ 'left': info.left, 'top': info.top });

                                if (ddIsVisible && info.inViewport === false) {
                                    dd.hide();
                                }
                                else if (!ddIsVisible && info.inViewport === true) {
                                    dd.show();
                                }
                            }
                        },
                        bindScroll: function () {
                            localScope.$root._absPosList.targetTextarea.parents().not('.absPosListScroll')
                                .filter(function () {
                                    return (this.clientHeight < this.scrollHeight || this.clientWidth < this.scrollWidth);
                                })
                                .addClass('absPosListScroll')
                                .on('scroll.absPosList', function (evt) {
                                    var ele = this,
                                        p = $(ele),
                                        scrollTop = p.scrollTop(),
                                        scrollLeft = p.scrollLeft(),
                                        topViewable = p.offset().top,
                                        leftViewable = p.offset().left,
                                        bottomViewable = topViewable + ele.clientHeight,
                                        rightViewable = leftViewable + ele.clientWidth,
                                        hasFocus = localScope.$root._absPosList.targetTextarea.is(':focus'),
                                        offsetTop = localScope.$root._absPosList.targetTextarea.offset().top + localScope.$root._absPosList.targetTextarea.outerHeight(),
                                        offsetLeft = localScope.$root._absPosList.targetTextarea.offset().left,
                                        dd = $('.uixDropdown-menu'),
                                        ddIsVisible = dd.is(':visible'),
                                        inViewport = ((topViewable < offsetTop) && (offsetTop < bottomViewable) && (leftViewable < offsetLeft) && (offsetLeft < rightViewable));

                                    dd.css({ 'left': offsetLeft, 'top': offsetTop });

                                    if (ddIsVisible && !inViewport) {
                                        dd.hide();
                                    }
                                    else if (!ddIsVisible && inViewport) {
                                        dd.show();
                                    }
                                });
                        },
                        unbindScroll: function () {
                            localScope.$root._absPosList.targetTextarea.parents('.absPosListScroll').removeClass('absPosListScroll').off('scroll.absPosList');
                        },
                        show: function () {
                            var deferred = $q.defer();
                            if (localScope.$root._absPosList.isOpened) {
                                localScope.$root._absPosList.hide().then(function () {
                                    localScope.$root._absPosList.show();
                                });
                            }
                            else {
                                localScope.$root._absPosList.isOpening = true;
                                localScope.$root._absPosList.isOpened = false;
                                localScope.$root._absPosList.targetTextarea.addClass('active');

                                var dd = $('.uixDropdown-menu'),
                                    info = localScope.$root._absPosList.getPosition();

                                localScope.$root._absPosList.bindScroll();

                                if (jQuery && jQuery.fn.animate) {
                                    dd.css({ 'left': info.left, 'top': info.top }).width(info.width).animate({ height: 'toggle', maxHeight: info.height }, 265, function () {
                                        localScope.$root._absPosList.isOpening = false;
                                        localScope.$root._absPosList.isOpened = true;
                                        localScope.$root._absPosList.isClosed = false;
                                        deferred.resolve();
                                    });
                                }
                                else {
                                    dd.css({ 'left': info.left, 'top': info.top, maxHeight: info.height }).width(info.width).height('toggle');
                                    localScope.$root._absPosList.isOpening = false;
                                    localScope.$root._absPosList.isOpened = true;
                                    localScope.$root._absPosList.isClosed = false;
                                    deferred.resolve();
                                }
                            }
                            return deferred.promise;
                        },
                        hide: function () {
                            var deferred = $q.defer();
                            localScope.$root._absPosList.isClosing = true;
                            localScope.$root._absPosList.isClosed = false;
                            localScope.$root._absPosList.targetTextarea.removeClass('active');

                            localScope.$root._absPosList.unbindScroll();

                            if (jQuery && jQuery.fn.animate) {
                                $('.uixDropdown-menu').animate({ height: 'toggle', maxHeight: 0 }, 265, function () {
                                    $(this).hide();
                                    localScope.$root._absPosList.isClosing = false;
                                    localScope.$root._absPosList.isClosed = true;
                                    localScope.$root._absPosList.isOpened = false;
                                    localScope.$root._absPosList.items = null;
                                    deferred.resolve();
                                });
                            }
                            else {
                                $('.uixDropdown-menu').height('toggle').css({ maxHeight: 0 });
                                localScope.$root._absPosList.isClosing = false;
                                localScope.$root._absPosList.isClosed = true;
                                localScope.$root._absPosList.isOpened = false;
                                localScope.$root._absPosList.items = null;
                                deferred.resolve();
                            }
                            return deferred.promise;
                        }
                    }

                    $(window).on('resize', function (evt) {
                        if (localScope.$root._absPosList.isOpened) {
                            localScope.$root._absPosList.reposition();
                        }
                    });
                }

                if (attr.ngDisabled) {
                    localScope.$parent.$watch(attr.ngDisabled, function (isDisabled) {
                        if (isDisabled) {
                            textarea.attr('disabled', 'disabled');
                        }
                        else {
                            textarea.removeAttr('disabled');
                        }
                    });
                }

                function setSelected(paramsObj) {
                    if (paramsObj.item == undefined) return;

                    if (isMultipleSelect) {
                        if (angular.isArray(paramsObj.modelValue)) {
                            var length = paramsObj.modelValue ? paramsObj.modelValue.length : 0,
                                i = 0;

                            while (i < length && !paramsObj.item._absPosSelected) {
                                paramsObj.item._absPosSelected = valueField ? angular.equals(paramsObj.item[valueField], paramsObj.modelValue[i][valueField]) : angular.equals(paramsObj.item, paramsObj.modelValue[i]);
                                i++;
                            }

                            if (paramsObj.item._absPosSelected) {
                                paramsObj.textToRender += paramsObj.textToRender == '' ? paramsObj.item[textField] : multiSelectDelimiter.concat(paramsObj.item[textField]);
                            }
                        }
                    }
                    else {
                        paramsObj.item._absPosSelected = valueField ? angular.equals(paramsObj.item[valueField], paramsObj.modelValue) : angular.equals(paramsObj.item, paramsObj.modelValue);
                        if (paramsObj.item._absPosSelected) {
                            paramsObj.textToRender = paramsObj.item[textField];
                        }
                    }
                }

                if (isMultipleSelect && angular.isArray(localScope.$parent[attr.ngModel])) {
                    localScope.$parent.$watchCollection(
                        function () {
                            return localScope.$parent[attr.ngModel];
                        },
                        function (newValue) {
                            var factoryObj = { item: null, modelValue: newValue, textToRender: '' };

                            angular.forEach(localScope.dataItems, function (item) {
                                factoryObj.item = item;
                                setSelected(factoryObj);
                            });

                            render(factoryObj.textToRender);
                        });
                }
                else {
                    localScope.$parent.$watch(
                        function () {
                            return localScope.$parent[attr.ngModel];
                        },
                        function (newValue, oldValue) {
                            if (!angular.equals(newValue, oldValue)) {
                                var factoryObj = { item: null, modelValue: $parse(attr.ngModel)(localScope.$parent), textToRender: '' };

                                angular.forEach(localScope.dataItems, function (item) {
                                    factoryObj.item = item;
                                    setSelected(factoryObj);
                                });

                                render(factoryObj.textToRender);

                            }
                        });
                }
                localScope.$parent.$watch(collection, function (items) {
                    var i = 0,
                        factoryObj = { item: null, modelValue: $parse(attr.ngModel)(localScope.$parent), textToRender: '' },
                        config = function (x) {
                            factoryObj.item = x;
                            setSelected(factoryObj);
                            x._absPosItemIndex = i;
                            x._absPosKeyScrolled = false;
                            localScope.dataItems.push(x);
                            i++;
                        };

                    localScope.dataItems = [];

                    if (hasFilter) {
                        if (localScope.$parent[filterArg]) {
                            angular.forEach($filter(filterName)(items, localScope.$parent[filterArg]), function (item) {
                                config(item);
                            });
                        }
                        else {
                            angular.forEach($filter(filterName)(items), function (item) {
                                config(item);
                            });
                        }
                    }
                    else {
                        angular.forEach(items, function (item) {
                            config(item);
                        });
                    }

                    if (!localScope.loadingOnDemand)
                        render(factoryObj.textToRender);

                    if (localScope.isTarget) {
                        addItems().then(function () {
                            localScope.loadingOnDemand = false;
                        });
                    }
                    else {
                        localScope.loadingOnDemand = false;
                    }
                });

                element.on('$destroy', function () {
                    $(this).off('.uixDropdown');
                });

                function bindLocalEvents() {
                    localScope.$root._absPosListClicked = localListClicked;
                    localScope.$root._absPosItemClicked = localItemClicked;
                    localScope.$root._absPosList.useCheckbox = useCheckbox;
                }

                function addItems() {
                    var deferred = $q.defer();
                    (function () {
                        var foundIndexes = [],
                            emptyIndex = -1,
                            i = 0;
                        localScope.$root._absPosList.items = [];
                        angular.forEach(localScope.dataItems, function (item) {
                            if (item._absPosSelected)
                                foundIndexes.push(i);
                            if (item[valueField] == undefined && emptyIndex == -1)
                                emptyIndex = i;
                            localScope.$root._absPosList.items.push(item);
                            i++;
                        });
                        if (!isMultipleSelect && foundIndexes.length > 1 && emptyIndex > -1) {
                            localScope.dataItems[emptyIndex]._absPosSelected = false;
                        }
                        deferred.resolve();
                    }());
                    return deferred.promise;
                }

                function showDropdown() {
                    if (!localScope.$root._absPosList.isOpened && !localScope.$root._absPosList.isOpening) {
                        localScope.isTarget = true;
                        localScope.$root._absPosList.height = hasCustomHeight ? customHeight : 265;
                        localScope.$root._absPosList.width = hasCustomWidth ? customWidth : textarea.outerWidth();

                        bindLocalEvents();
                        addItems().then(function () {
                            localScope.$root._absPosList.show();
                        });
                    }

                }

                function hideDropdown() {
                    if (!localScope.$root._absPosList.isClosed && !localScope.$root._absPosList.isClosing) {
                        localScope.$root._absPosList.hide();
                        localScope.isTarget = false;
                    }
                }

                localScope.modelBlurred = function (evt) {
                    if (attr.uixModelBlur && attr.uixModelBlur !== "") {
                        $parse(attr.uixModelBlur)(localScope.$parent, { $event: evt });
                    }
                };


                localScope.dropdownButtonClicked = function (evt) {
                    localScope.$root._absPosList.canOpen = true;
                    localScope.$root._absPosList.targetTextarea = $(evt.target).parents('.input-group').first().children('textarea').first();
                    showDropdown();
                    evt.stopPropagation();
                    evt.preventDefault();
                    return false;
                };

                localScope.focused = function (evt) {
                    var focusFunc = function () {
                        localScope.$root._absPosList.focusTimer = $timeout(function () {
                            localScope.$root._absPosList.targetTextarea = $(evt.target);
                            $timeout.cancel(localScope.$root._absPosList.focusTimer);
                            localScope.$root._absPosList.focusTimer = null;
                            showDropdown();
                            if (onFocusFunc && onFocusFunc !== "") {
                                $parse(onFocusFunc)(localScope.$parent, { $event: { target: element } });
                            }
                        }, 400);
                    };

                    if (localScope.$root._absPosList.focusTimer) {
                        $timeout.cancel(localScope.$root._absPosList.focusTimer);
                        localScope.$root._absPosList.focusTimer = null;
                    }

                    if (localScope.$root._absPosList.isRightClick) {
                        return;
                    }

                    if (localScope.$root._absPosList.isOpening || localScope.$root._absPosList.isOpened || !localScope.$root._absPosList.canClose) {
                        localScope.$root._absPosList.hide().then(function () {
                            localScope.$root._absPosList.canClose = true;
                            focusFunc();
                        });
                    }
                    else {
                        focusFunc();
                    }
                };

                localScope.clicked = function (evt) {
                    if (localScope.$root._absPosList.isClosed) {
                        localScope.$root._absPosList.targetTextarea = $(evt.target);
                        showDropdown();
                    }
                    else if (localScope.$root._absPosList.items == null) {
                        addItems();
                    }

                    evt.stopPropagation();
                    evt.preventDefault();
                    return false;
                };

                localScope.blurred = function (evt) {
                    if (localScope.$root._absPosList.focusTimer) {
                        $timeout.cancel(localScope.$root._absPosList.focusTimer);
                        localScope.$root._absPosList.focusTimer = null;
                    }

                    if (localScope.$root._absPosList.canClose) {
                        if (localScope.selectedIndex > -1 && localScope.selectedIndex < localScope.dataItems.length && localScope.$root._absPosList.items) {
                            setModel(localScope.$root._absPosList.items[localScope.selectedIndex]);
                        }
                        if (localScope.$root._absPosList.isOpened) {
                            hideDropdown();
                        }
                    }
                };

                localScope.mousedowned = function (evt) {
                    localScope.$root._absPosList.isRightClick = evt.which === 3;
                    localScope.$root._absPosList.canClose = false;
                };

                localScope.keydowned = function (evt) {
                    var isEnter = evt.which == 13;

                    if (isEnter && localScope.selectedIndex > -1 && localScope.selectedIndex < localScope.$root._absPosList.items.length) {
                        if (!isMultipleSelect) {
                            angular.forEach(localScope.dataItems, function (item) {
                                item._absPosSelected = false;
                            });
                        }

                        localScope.$root._absPosList.items[localScope.selectedIndex]._absPosSelected = !localScope.$root._absPosList.items[localScope.selectedIndex]._absPosSelected;
                        setModel(localScope.$root._absPosList.items[localScope.selectedIndex], isMultipleSelect ? addItems : hideDropdown);

                        evt.stopPropagation();
                        evt.preventDefault();
                        return false;
                    }
                };

                localScope.$root._absPosChangeTimer = null;

                localScope.keyuped = function (evt) {
                    var self = $(evt.target),
                        isAlphanumeric = /\w/.test(String.fromCharCode(evt.which)),
                        isDelete = evt.which == 46,
                        isBackspace = evt.which == 8,
                        isUpArrow = evt.which == 38,
                        isDownArrow = evt.which == 40,
                        value = self.val(),
                        valueArray = isMultipleSelect ? value.split(multiSelectDelimiter) : [value],
                        filteredArr = enableStrictText ? [] : null,
                        pattern = new RegExp('^' + valueArray[valueArray.length - 1], ['i']),
                        isDelimiter = isMultipleSelect && delimiterPattern.test(value);

                    if (isUpArrow || isDownArrow) {
                        var dd = $('.uixDropdown-menu'),
                            itemHeight = 0,
                            selectorFilter = '',
                            ddElem = dd.get()[0];

                        if (isUpArrow && localScope.selectedIndex > 0) {
                            localScope.selectedIndex--;
                            selectorFilter = ':lt(' + localScope.selectedIndex.toString() + ')';
                            dd.find('li').filter(selectorFilter).each(function () {
                                itemHeight += $(this).outerHeight();
                            });
                            if (ddElem.clientHeight < ddElem.scrollHeight && itemHeight < ddElem.scrollTop) {
                                ddElem.scrollTop = itemHeight;
                            }
                            localScope.$root._absPosList.items[localScope.selectedIndex]._absPosKeyScrolled = true;
                            if (localScope.selectedIndex < (localScope.$root._absPosList.items.length - 1)) {
                                localScope.$root._absPosList.items[localScope.selectedIndex + 1]._absPosKeyScrolled = false;
                            }
                        }
                        else if (isDownArrow && localScope.selectedIndex < (localScope.$root._absPosList.items.length - 1)) {
                            localScope.selectedIndex++;
                            selectorFilter = ':lt(' + (localScope.selectedIndex + 1).toString() + ')';
                            var items = dd.find('li').filter(selectorFilter);
                            items.each(function () {
                                itemHeight += $(this).outerHeight();
                            });
                            if (ddElem.clientHeight < ddElem.scrollHeight && itemHeight > ddElem.clientHeight) {
                                ddElem.scrollTop = ddElem.scrollTop + items.last().outerHeight();
                            }
                            localScope.$root._absPosList.items[localScope.selectedIndex]._absPosKeyScrolled = true;
                            if (localScope.selectedIndex > 0) {
                                localScope.$root._absPosList.items[localScope.selectedIndex - 1]._absPosKeyScrolled = false;
                            }
                        }
                    }
                    else if (isAlphanumeric || isDelimiter || isDelete || isBackspace) {
                        if (onChangeFunc && onChangeFunc !== "") {
                            if (localScope.$root._absPosChangeTimer) {
                                $timeout.cancel(localScope.$root._absPosChangeTimer);
                                localScope.$root._absPosChangeTimer = null;
                            }
                            localScope.$root._absPosChangeTimer = $timeout(function () {
                                if (value == '') {
                                    //localScope.dataItems = [];
                                }
                                else {
                                    localScope.loadingOnDemand = true;
                                    $parse(onChangeFunc)(localScope.$parent, { $event: { target: element, value: value, showLoadingImg: localScope.loadingOnDemand } });
                                }
                            }, 400);
                        }
                        else {
                            if (value == '' || isDelimiter) {
                                localScope.$root._absPosList.items = [];
                                angular.forEach(localScope.dataItems, function (item) {
                                    localScope.$root._absPosList.items.push(item);
                                });
                            }
                            else {
                                angular.forEach(localScope.dataItems, function (item) {
                                    if (item[textField] != undefined && pattern.test(item[textField])) {
                                        filteredArr.push(item);
                                    }
                                });

                                if (enableStrictText && filteredArr.length == 0) {
                                    textarea.val(value.substr(0, value.length - 1));
                                }
                                else {
                                    localScope.$root._absPosList.items = [];
                                    angular.forEach(filteredArr, function (item) {
                                        localScope.$root._absPosList.items.push(item);
                                    });
                                }

                                if (localScope.$root._absPosList.items[localScope.selectedIndex] !== undefined) {
                                    localScope.$root._absPosList.items[localScope.selectedIndex]._absPosSelected = false;
                                }
                                localScope.selectedIndex = 0;
                                localScope.$root._absPosList.items[localScope.selectedIndex]._absPosSelected = true;
                                //setModel(localScope.$root._absPosList.items[localScope.selectedIndex], null);

                            }
                        }
                        evt.stopPropagation();
                        evt.preventDefault();
                        return false;
                    }
                };

                var localListClicked = function (evt) {
                    localScope.$root._absPosList.canClose = false;
                    evt.stopPropagation();
                    evt.preventDefault();
                    return false;
                }

                var localItemClicked = function (evt, item) {
                    localScope.$root._absPosList.canClose = false;
                    localScope.$root._absPosList.isItemClick = true;
                    if (item) {
                        localScope.selectedIndex = item._absPosItemIndex;
                        item._absPosSelected = !item._absPosSelected;
                        setModel(item, isMultipleSelect ? null : hideDropdown);
                    }
                    evt.stopPropagation();
                    evt.preventDefault();

                    return false;
                }

                function setModel(item, callback) {
                    item._absPosKeyScrolled = false;
                    if (isMultipleSelect && angular.isArray(localScope.$parent[attr.ngModel])) {
                        var found = false,
                            length = localScope.$parent[attr.ngModel].length,
                            i = 0,
                            textToRender = textarea.val(),
                            textArray = [];

                        while (i < length && !found) {
                            found = angular.equals(item, localScope.$parent[attr.ngModel][i]);
                            if (!found)
                                i++;
                        }

                        if (item._absPosSelected && !found) {
                            localScope.$parent[attr.ngModel].push(item);
                            length++;
                        }
                        else if (!item._absPosSelected && found) {
                            localScope.$parent[attr.ngModel].splice(i, 1);
                            length--;
                        }

                        i = 0;
                        while (i < length) {
                            textArray.push(localScope.$parent[attr.ngModel][i][textField]);
                            i++;
                        }
                        $timeout(function () {
                            localScope.$root._absPosList.reposition();
                        }, 50);

                        render(textArray.join(multiSelectDelimiter));
                    }
                    else {
                        angular.forEach(localScope.dataItems, function (li) {
                            li._absPosSelected = angular.equals(li, item);
                        });
                        ngModel.$setViewValue(valueField ? item[valueField] : item);
                        render(item[textField]);
                    }


                    if (callback) {
                        callback();
                    }
                }

                function render(text) {
                    if (textarea.val() !== text) {
                        textarea.val(text);

                        if (isResizeable) {
                            resizeTextArea(text);
                        }
                    }
                }

                function resizeTextArea(itemText) {
                    var text = itemText ? itemText : textarea.val(),
                        wordsArray = text.split(/\s/),
                        wordsLength = wordsArray.length,
                        textWidth = textarea.width() - textareaPaddingRight,
                        charsPerRow = Math.floor(textWidth / textareaFontWidth),
                        rowCount = 1,
                        charCount = 0,
                        i = 0;

                    while (i < wordsLength) {
                        charCount = charCount + wordsArray[i].length + 1;
                        if (wordsArray[i + 1] !== undefined && (charCount + wordsArray[i + 1].length) > charsPerRow) {
                            rowCount++;
                            charCount = 0;
                        }
                        i++;
                    }

                    if (jQuery && jQuery.fn.animate) {
                        textarea.animate({
                            rows: rowCount //rowCount < 2 ? 2 : rowCount
                        }, 400, function () {
                        });
                    }
                    else {
                        textarea.attr('rows', rowCount < 2 ? 2 : rowCount);
                    }
                }


                // required validator
                if (attr.required || attr.ngRequired) {
                    var requiredValidator = function (value) {
                        ngModel.$setValidity('required', !attr.required || (value && value.length));
                        return value;
                    };

                    ngModel.$parsers.push(requiredValidator);
                    ngModel.$formatters.unshift(requiredValidator);

                    attr.$observe('required', function () {
                        requiredValidator(ngModel.$viewValue);
                    });
                }

            }
        }
    }]);

    controls.directive('uixInputListSelection', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: 'ngModel',
            replace: false,
            priority: -1,
            terminal: true,
            compile: function (element, attrs, transclude) {
                var hoverClass = 'hover',
                    hoverProp = '_uixHover',
                    selectedClass = 'selected',
                    selectedProp = '_uixSelected',
                    activeIndexProp = '_uixActiveIndex',
                    cachedActiveIndexProp = '_uixCachedActiveIndex',
                    selectedIndexProp = '_uixSelectedIndex',
                    collectionName = attrs.uixInputListSelection != undefined ? attrs.uixInputListSelection : '',
                    repeaterElement = _uix.findNgRepeatElement(collectionName),
                    repeaterExpProps = _uix.getNgRepeatProps(repeaterElement),
                    repeaterObjName = repeaterExpProps.objName,
                    repeater = repeaterElement.parent(),
                    isKVP = repeaterExpProps.isKeyValuePair,
                    hasTextField = attrs.textField && attrs.textField !== "",
                    isObjectType = false,
                    isValueType = false;

                if (isKVP) {
                    throw new Error('ng-repeat Key Value Pair expression is not supported at this time. Must be an array of objects.');
                    return;
                }

                _uix.appendNgClass(repeaterElement, hoverProp, hoverClass, repeaterObjName);
                _uix.appendNgClass(repeaterElement, selectedProp, selectedClass, repeaterObjName);

                return function (scope, element, attrs, ngModel) {
                    var collection = scope.$eval(collectionName);

                    scope.$watchCollection(collectionName, function (newCollection) {
                        isValueType = collection && collection.length > 0 && (angular.isString(collection[0]) || angular.isNumber(collection[0]));
                        if (isValueType) {
                            throw new Error('ng-repeat expression must be an array of objects.');
                            return;
                        }
                        isObjectType = collection && collection.length > 0 && angular.isObject(collection[0]) && !isKVP;
                        if (collection && collection.length > 0 && isObjectType && !hasTextField) {
                            throw new Error('text-field attribute is required with the uix-input-list-selection directive.');
                            return;
                        }
                        //scope[cachedActiveIndexProp] = -1;
                        selectItem();
                    });

                    
                    var onModelInit = scope.$watch(attrs.ngModel, function (val1, val2) {
                        if (!angular.equals(val1, val2)) {
                            selectItem();
                            onModelInit();
                        }
                    });

                    function getItemValue(index) {
                        var i = angular.isDefined(index) ? index : -1,
                            val = null;

                        if (angular.isDefined(collection[i]) && collection[i] != null) {
                            if (isKVP) {
                                for (var prop in collection[i]) {
                                    if (collection[i].hasOwnProperty(prop)) {
                                        val = collection[i][prop];
                                        break;
                                    }
                                }
                            }
                            else if (isObjectType && hasTextField) {
                                val = collection[i][attrs.textField];
                            }
                            else if (isValueType) {
                                val = collection[i];
                            }
                        }
                        return val;
                    }

                    function selectItem(useActiveIndex) {
                        var activeIndex = scope[activeIndexProp],
                            selectedIndex = scope[selectedIndexProp],
                            ngModelValue = null,
                            ngModelPattern = null,
                            itemValue = null,
                            i = 0,
                            length = collection ? collection.length : 0;

                        if (collection[activeIndex] != undefined)
                            collection[activeIndex][hoverProp] = false;

                        if (collection[selectedIndex] != undefined)
                            collection[selectedIndex][selectedProp] = false;

                        selectedIndex = -1;

                        if (useActiveIndex) {
                            selectedIndex = activeIndex;
                            itemValue = getItemValue(selectedIndex);
                        }
                        else if (!useActiveIndex && (isKVP || (isObjectType && hasTextField) || isValueType)) {
                            ngModelValue = scope.$eval(attrs.ngModel);
                            ngModelPattern = new RegExp((angular.isDefined(ngModelValue) && ngModelValue != null && ngModelValue.replace(/\s/, '').length > 0) ? ''.concat('^', ngModelValue, '$') : '^[\\s]*$', ['i']);
                            while (i < length) {
                                itemValue = getItemValue(i);
                                if (ngModelPattern.test(itemValue)) {
                                    selectedIndex = i;
                                    break;
                                }
                                i++;
                            };
                        }

                        //scope[selectedIndexProp] = scope[activeIndexProp] = scope[cachedActiveIndexProp] = selectedIndex;
                        scope[selectedIndexProp] = scope[activeIndexProp] = selectedIndex;

                        if (angular.isDefined(collection[selectedIndex])) {
                            collection[selectedIndex][selectedProp] = true;
                            ngModel.$setViewValue(itemValue);
                            $(element).val(itemValue);
                        }

                    }

                    repeater.on('mousedown', function (evt) {
                        var self = $(evt.target),
                            selfIndex = self.index(),
                            selfScope = null;
                        scope.$apply(function () {
                            var itemValue = getItemValue(selfIndex);

                            if (angular.isDefined(collection[scope[activeIndexProp]]) && collection[scope[activeIndexProp]] != null) {
                                collection[scope[activeIndexProp]][hoverProp] = false;
                            }
                            if (angular.isDefined(collection[scope[selectedIndexProp]]) && collection[scope[selectedIndexProp]] != null) {
                                collection[scope[selectedIndexProp]][selectedProp] = false;
                            }

                            scope[activeIndexProp] = scope[selectedIndexProp] = selfIndex;
                            collection[scope[selectedIndexProp]][selectedProp] = true;
                            ngModel.$setViewValue(itemValue);
                            $(element).val(itemValue);
                        });
                        evt.preventDefault();
                        evt.stopPropagation();
                        return false;
                    });


                    element
                        .on('blur', function (evt) {
                            var itemObj = null;

                            scope.$apply(function () {
                                selectItem(true);
                                if (attrs.onSelect && attrs.onSelect != '') {
                                    itemObj = repeater.children().eq(scope[selectedIndexProp]);
                                    $parse(attrs.onSelect)(scope, { $event: { target: $(evt.target), listItemTarget: itemObj, dataItem: collection[scope[selectedIndexProp]] } });
                                }
                            });
                        })
                        .on('keydown', function (evt) {
                            var isUpArrow = evt.which == 38,
                                isDownArrow = evt.which == 40,
                                isEnterKey = evt.which == 13,
                                isDelete = evt.which == 46,
                                isBackspace = evt.which == 8,
                                isAlphanumeric = /\w/.test(String.fromCharCode(evt.which));

                            if (isUpArrow || isDownArrow || isEnterKey) {
                                var input = $(this),
                                    activeIndex = scope[activeIndexProp],
                                    selectedIndex = scope[selectedIndexProp],
                                    listElem = repeater.get()[0],
                                    itemObj = null,
                                    itemHeight = 0,
                                    selectorFilter = '';

                                //if (activeIndex < 0 && scope[cachedActiveIndexProp] > -1) {
                                //    activeIndex = scope[cachedActiveIndexProp];
                                //}

                                if (isEnterKey) {
                                    scope.$apply(selectItem(true));
                                }
                                else {
                                    if (isUpArrow && activeIndex > 0) {
                                        scope.$apply(function () {
                                            if (collection[activeIndex] != undefined)
                                                collection[activeIndex][hoverProp] = false;

                                            activeIndex--;
                                            scope[activeIndexProp] = activeIndex;

                                            if (collection[activeIndex] != undefined)
                                                collection[activeIndex][hoverProp] = true;

                                            if (repeater && repeater.length > 0) {
                                                selectorFilter = ':lt('.concat(activeIndex.toString(), ')');
                                                var listParentElem = repeater.parent().get()[0],
                                                    scrollContainer = null;

                                                repeater.find(repeaterElement.prop('tagName')).filter(selectorFilter).each(function () {
                                                    itemHeight += $(this).outerHeight();
                                                });

                                                if (listElem.clientHeight < listElem.scrollHeight) {
                                                    scrollContainer = listElem;
                                                }
                                                else if (listParentElem && listParentElem.clientHeight < listParentElem.scrollHeight) {
                                                    scrollContainer = listParentElem;
                                                }

                                                if (scrollContainer && scrollContainer.clientHeight < scrollContainer.scrollHeight) {
                                                    if (itemHeight < scrollContainer.scrollTop) {
                                                        scrollContainer.scrollTop = itemHeight;
                                                    }
                                                }

                                            }

                                            if (attrs.onDirectional && attrs.onDirectional != '') {
                                                itemObj = repeater.children().eq(selectedIndex);
                                                $parse(attrs.onDirectional)(scope, { $event: { target: $(evt.target), listItemTarget: itemObj, dataItem: collection[activeIndex] } });
                                            }

                                        });
                                    }
                                    else if (isDownArrow && activeIndex < (collection.length - 1)) {
                                        scope.$apply(function () {
                                            if (collection[activeIndex] != undefined)
                                                collection[activeIndex][hoverProp] = false;

                                            activeIndex++;
                                            scope[activeIndexProp] = activeIndex;

                                            if (collection[activeIndex] != undefined)
                                                collection[activeIndex][hoverProp] = true;

                                            if (repeater && repeater.length > 0) {
                                                selectorFilter = ':lt('.concat((activeIndex + 1).toString(), ')');
                                                var items = repeater.find(repeaterElement.prop('tagName')).filter(selectorFilter),
                                                    listParentElem = repeater.parent().get()[0],
                                                    scrollContainer = null;

                                                items.each(function () {
                                                    itemHeight += $(this).outerHeight();
                                                });

                                                if (listElem.clientHeight < listElem.scrollHeight) {
                                                    scrollContainer = listElem;
                                                }
                                                else if (listParentElem && listParentElem.clientHeight < listParentElem.scrollHeight) {
                                                    scrollContainer = listParentElem;
                                                }

                                                if (scrollContainer && scrollContainer.clientHeight < scrollContainer.scrollHeight) {
                                                    if (itemHeight < scrollContainer.scrollTop) {
                                                        scrollContainer.scrollTop = (itemHeight - items.last().outerHeight());
                                                    }
                                                    else if (itemHeight > scrollContainer.clientHeight) {
                                                        scrollContainer.scrollTop = scrollContainer.scrollTop + items.last().outerHeight();
                                                    }
                                                }
                                            }

                                            if (attrs.onDirectional && attrs.onDirectional != '') {
                                                itemObj = repeater.children().eq(selectedIndex);
                                                $parse(attrs.onDirectional)(scope, { $event: { target: $(evt.target), listItemTarget: itemObj, dataItem: collection[activeIndex] } });
                                            }

                                        });

                                    }
                                }

                            }
                            else if (isAlphanumeric || isDelete || isBackspace) {
                                if (collection[scope[activeIndexProp]] != undefined)
                                    collection[scope[activeIndexProp]][hoverProp] = false;

                                if (collection[scope[selectedIndexProp]] != undefined)
                                    collection[scope[selectedIndexProp]][selectedProp] = false;

                                //scope[cachedActiveIndexProp] = scope[activeIndexProp];
                                scope[selectedIndexProp] = scope[activeIndexProp] = -1;
                            }
                        });
                }
            }
        };
    }]);

    controls.directive('uixModelBlur', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: 'ngModel',
            replace: false,
            link: function (scope, element, attrs, ngModel) {
                var fn = $parse(attrs['uixModelBlur']);

                $(element).on('blur.uixModelBlur', function (evt) {
                    scope.$apply(function () {
                        fn(scope, { $event: { target: element, isDirty: ngModel.$dirty, isValid: ngModel.$valid, value: ngModel.$modelValue } });
                    });
                })
                .on('$destroy', function () {
                    $(this).off('.uixModelBlur');
                });

            }
        }
    }]);

    controls.directive('uixModelWatch', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: 'ngModel',
            replace: false,
            link: function (scope, element, attrs, ngModel) {
                var fn = $parse(attrs['uixModelWatch']);

                scope.$watch(attrs.ngModel,
                function (newVal, oldVal) {
                    if (newVal != oldVal) {
                        fn(scope, { $event: { target: element, isDirty: ngModel.$dirty, isValid: ngModel.$valid, newValue: newVal, oldValue: oldVal } });
                    }
                }, true);
            }
        }
    }]);

    controls.directive('uixLoadingInline', [function () {
        return function (scope, element, attrs) {
            var ele = $(element),
                disableOnLoad = scope.$eval(attrs.disableOnLoad) === true;

            scope.$watch(attrs.uixLoadingInline, function (value) {
                if (value) {
                    ele.addClass("loadingInlineBG");
                    if (disableOnLoad) {
                        ele.attr('disabled', 'disabled');
                    }
                }
                else if (!value) {
                    ele.removeClass("loadingInlineBG");
                    if (disableOnLoad) {
                        ele.removeAttr('disabled');
                    }
                }
            });

        };

    }]);

    controls.directive('uixLoadingPanel', [function () {
        return function (scope, element, attrs) {
            var ele = $(element),
                parent = ele.parent(),
                paddingTop = ele.css('paddingTop'),
                paddingLeft = ele.css('paddingLeft'),
                isParentRelative = /relative/gi.test(parent.css('position')),
                loadingPanel = $('<div class="loadingPanel"></div>'),
                loadingImage = $('<div class="loadingImage" ></div>');

            parent.prepend(loadingImage).prepend(loadingPanel);

            scope.$watch(function () { return scope.$eval(attrs.uixLoadingPanel); }, function (value) {
                var panel = parent.children('.loadingPanel');
                var img = parent.children('.loadingImage');

                if (value && !panel.is(':visible')) {
                    panel.fadeIn(300);
                    img.fadeIn(300);
                    parent.addClass('isLoading');
                }
                else if (!value) {
                    panel.fadeOut(500);
                    img.fadeOut(500);
                    parent.removeClass('isLoading');
                }
            }, true);
        };

    }]);

    controls.directive('uixCollapsibleHeader', ['$parse', '$timeout', function ($parse, $timeout) {
        return {
            restrict: 'A',
            priority: 0,
            link: function (scope, element, attrs) {
                var showIcon = scope.$eval(attrs.showIcon) === true,
                    isAccordian = scope.$eval(attrs.isAccordian) === true,
                    isCollapsed = attrs.isCollapsed == undefined ? false : (scope.$eval(attrs.isCollapsed) === true || (scope.$eval(attrs.isCollapsed) !== false && isAccordian)),
                    isSplitHeight = ((attrs.isSplitheight == undefined || (scope.$eval(attrs.isSplitheight) === true)) && $(element).siblings('div[uix-collapsible-header]:not([is-splitheight]), div[is-splitheight="true"]').length > 0),
                    hasHeight = attrs.contentHeight !== undefined && attrs.contentHeight.length > 0,
                    isPercentage = hasHeight && (attrs.contentHeight.indexOf('%') > 0),
                    contentHeight = hasHeight ? parseInt(attrs.contentHeight.replace(/[a-z\%]/ig, '')) : -1,
                    onExpand = attrs.onExpand,
                    onCollapse = attrs.onCollapse,
                    self = $(element),
                    collapsibleContent = self.next(),
                    headerClass = 'collapsible-header'.concat(isAccordian ? ' accordian-header' : '', isCollapsed ? '' : ' expanded');

                if (showIcon) {
                    self.prepend(function () {
                        return $('<span class="glyphicon ' + isCollapsed ? 'glyphicon-chevron-right' : 'glyphicon-chevron-down' + '" style="margin-left:-5px; margin-right:5px"></span>');
                    });
                }

                function setContentHeights(content, callback) {
                    var //visibleSiblings = content.siblings('.collapsible-content').filter(':visible'),
                        parent = content.parent(),
                        visibleSiblings = parent.children('div[uix-collapsible-header]').next().not(content).filter(':visible'),
                        parentHeight = parent.height(),
                        headers = parent.children('div[uix-collapsible-header]'),
                        otherSiblings = parent.children().not(function () { return $(this).attr('uix-collapsible-header') != undefined || $(this).prev('div[uix-collapsible-header]').length > 0; }),
                        headersHeight = (headers.outerHeight() * headers.length),
                        othersTotalHeight = 0,
                        contents = [],
                        sumCustomHeight = 0,
                        averageHeight = 0,
                        isExpanding = content.hasClass('isExpanding'),
                        sib = null,
                        sibHeight = 0,
                        sibData = null,
                        sibIndex = -1,
                        contentIndex = content.index(),
                        contentData = isExpanding ? content.data('uixCollapsibleHeader') : null,
                        contentHeightObj = isExpanding ? { index: contentIndex, height: 0, isTarget: true } : null,
                        isInserted = false,
                        length = 0,
                        x = 0,
                        customHeightCount = 0,
                        containerHeight = 0,
                        reducedHeight = 0;

                    otherSiblings.each(function () {
                        othersTotalHeight += $(this).outerHeight();
                    });

                    containerHeight = (parentHeight - othersTotalHeight - headersHeight);

                    if (isExpanding) {
                        if (contentData.hasHeight && !isNaN(contentData.height)) {
                            contentHeightObj.height = contentData.isPercentage ? (containerHeight * (contentData.height / 100)) : contentData.height;
                            sumCustomHeight += contentHeightObj.height;
                            customHeightCount += 1;
                        }
                        contents.push(contentHeightObj);
                    }

                    visibleSiblings.each(function () {
                        sib = $(this);
                        sibData = sib.data('uixCollapsibleHeader');
                        sibIndex = sib.index();
                        sibHeight = sibData.hasHeight && !isNaN(sibData.height)
                            ? sibData.isPercentage ? (containerHeight * (sibData.height / 100)) : sibData.height
                            : 0;
                        sumCustomHeight += sibData.hasHeight ? sibHeight : 0;
                        contents.push({ index: sibIndex, height: sibHeight, isTarget: false });
                        customHeightCount += sibData.hasHeight ? 1 : 0;
                    });


                    reducedHeight = (containerHeight - sumCustomHeight);
                    averageHeight = Math.ceil((reducedHeight > 0 ? reducedHeight : containerHeight) / (reducedHeight > 0 && (contents.length > customHeightCount) ? (contents.length - customHeightCount) : contents.length));

                    length = contents.length;
                    x = 0;

                    if (length === 1) {
                        contents[0].height = containerHeight;
                    }

                    while (x < length) {
                        if (callback && ((x + 1) == length)) {
                            if (contents[x].isTarget) {
                                parent.children().eq(contents[x].index).height(1).show().animate({ 'height': contents[x].height > 0 ? contents[x].height : averageHeight }, function () {
                                    callback();
                                });
                            }
                            else {
                                parent.children().eq(contents[x].index).animate({ 'height': contents[x].height > 0 ? contents[x].height : averageHeight }, function () {
                                    callback();
                                });
                            }
                        }
                        else {
                            if (contents[x].isTarget) {
                                parent.children().eq(contents[x].index).height(1).show().animate({ 'height': contents[x].height > 0 ? contents[x].height : averageHeight });
                            }
                            else {
                                parent.children().eq(contents[x].index).animate({ 'height': contents[x].height > 0 ? contents[x].height : averageHeight });
                            }
                        }
                        x++;
                    }

                    content.removeClass('isExpanding');

                }

                collapsibleContent.data('uixCollapsibleHeader', { hasHeight: hasHeight, isPercentage: isPercentage, height: contentHeight });

                self.data('uixCollapsibleHeader', { isCollapsed: isCollapsed }).addClass(headerClass)
                    .on('click.uixCollapsibleHeader', { isAccordian: isAccordian }, function (evt) {
                        var header = $(this),
                            content = header.next('.collapsible-content'),
                            opts = header.data('uixCollapsibleHeader'),
                            isLoading = content.hasClass('isLoading') || content.find('.isLoading').length > 0,
                            visibleSiblings = content.siblings('.collapsible-content').filter(':visible');

                        if (isLoading) return;

                        if (!opts.isCollapsed) {
                            if (content.siblings('.collapsible-header').filter('div:not([is-splitheight]), div[is-splitheight="true"]').length > 1 && visibleSiblings.length == 0) return;

                            header.find('span').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-right');
                            content.slideUp(400, function () {
                                header.removeClass('expanded').trigger('header-collapse.uixCollapsibleHeader');
                                scope.$apply(function () {
                                    $parse(onCollapse)(scope, { $event: { target: header, content: content } });
                                });
                            });
                            if (isSplitHeight) {
                                setContentHeights(content, function () { header.removeClass('expanded'); });
                            }
                            opts.isCollapsed = !opts.isCollapsed;
                        }
                        else {
                            header.addClass('expanded')
                                .find('span').removeClass('glyphicon-chevron-right').addClass('glyphicon-chevron-down');

                            if (evt.data.isAccordian && visibleSiblings.length > 0) {
                                visibleSiblings.slideUp(400, function () {
                                }).each(function () {
                                    $(this).prev().data('uixCollapsibleHeader').isCollapsed = true;
                                });
                            }
                            header.trigger('header-before-expand.uixCollapsibleHeader');
                            if (isSplitHeight) {
                                setContentHeights(content.addClass('isExpanding'), function () {
                                    header.trigger('header-expand.uixCollapsibleHeader');
                                    scope.$apply(function () {
                                        $parse(onExpand)(scope, { $event: { target: header, content: content } });
                                    });
                                });
                            }
                            else {
                                content.slideDown(400, function () {
                                    header.trigger('header-expand.uixCollapsibleHeader');
                                    scope.$apply(function () {
                                        $parse(onExpand)(scope, { $event: { target: header, content: content } });
                                    });
                                });
                            }
                            opts.isCollapsed = !opts.isCollapsed;
                        }
                    })
                    .on('$destroy', function () {
                        $(this).off('.uixCollapsibleHeader');
                    });

                if (isCollapsed) {
                    collapsibleContent.hide();
                }
                if (isSplitHeight) {
                    if (self[0] === self.parent().children('div[uix-collapsible-header]').not('div[is-collapsed="true"]').last()[0]) {
                        $timeout(function () {
                            setContentHeights(collapsibleContent.addClass('isExpanding'));
                        }, 100);
                    }
                }

                if (!collapsibleContent.hasClass('collapsible-content')) {
                    collapsibleContent.addClass('collapsible-content');
                }

            }
        }
    }]);

}(window, jQuery));

